import { useState, useEffect } from 'react';
import { AppProvider, useApp } from '@/context/AppContext';
import { AdminLayout } from '@/components/Layout';
import { LoginPage } from '@/pages/LoginPage';
import { DashboardPage } from '@/pages/DashboardPage';
import { ChitGroupsPage } from '@/pages/ChitGroupsPage';
import { SubscribersPage } from '@/pages/SubscribersPage';
import { AuctionPage } from '@/pages/AuctionPage';
import { PaymentsPage } from '@/pages/PaymentsPage';
import { CollectionsPage, OutstandingPage, LedgerPage } from '@/pages/CollectionsPage';
import {
  DividendsPage, PrizePaymentsPage, ReconciliationPage, ReportsPage,
  CalculatorPage, BranchesPage, StaffPage, DocumentsPage,
  NotificationsPage, AuditTrailPage, SettingsPage,
} from '@/pages/AdminPages';
import { CustomerPortal } from '@/pages/CustomerPortal';
import type { TranslationKey } from '@/i18n/translations';

function AppContent() {
  const { role, isCustomerPortal } = useApp();
  const [page, setPage] = useState('dashboard');

  useEffect(() => {
    if (role) {
      setPage(role === 'customer' ? 'home' : 'dashboard');
    }
  }, [role]);

  if (!role) {
    return <LoginPage />;
  }

  if (isCustomerPortal || role === 'customer') {
    return <CustomerPortal />;
  }

  const pageTitles: Record<string, TranslationKey> = {
    dashboard: 'dashboard', chitGroups: 'chitGroups', subscribers: 'subscribers',
    auctions: 'auctions', collections: 'collections', payments: 'payments',
    dividends: 'dividends', prizePayments: 'prizePayments', outstanding: 'outstanding',
    ledger: 'ledger', reconciliation: 'reconciliation', reports: 'reports',
    calculator: 'chitCalculator', branches: 'branches', staff: 'staffRoles',
    documents: 'documents', notifications: 'notifications', auditTrail: 'auditTrail',
    settings: 'settings',
  };

  const renderPage = () => {
    switch (page) {
      case 'dashboard': return <DashboardPage onNavigate={setPage} />;
      case 'chitGroups': return <ChitGroupsPage onNavigate={setPage} />;
      case 'subscribers': return <SubscribersPage onNavigate={setPage} />;
      case 'auctions': return <AuctionPage onNavigate={setPage} />;
      case 'collections': return <CollectionsPage onNavigate={setPage} />;
      case 'payments': return <PaymentsPage onNavigate={setPage} />;
      case 'dividends': return <DividendsPage onNavigate={setPage} />;
      case 'prizePayments': return <PrizePaymentsPage onNavigate={setPage} />;
      case 'outstanding': return <OutstandingPage onNavigate={setPage} />;
      case 'ledger': return <LedgerPage onNavigate={setPage} />;
      case 'reconciliation': return <ReconciliationPage onNavigate={setPage} />;
      case 'reports': return <ReportsPage onNavigate={setPage} />;
      case 'calculator': return <CalculatorPage onNavigate={setPage} />;
      case 'branches': return <BranchesPage onNavigate={setPage} />;
      case 'staff': return <StaffPage onNavigate={setPage} />;
      case 'documents': return <DocumentsPage onNavigate={setPage} />;
      case 'notifications': return <NotificationsPage onNavigate={setPage} />;
      case 'auditTrail': return <AuditTrailPage onNavigate={setPage} />;
      case 'settings': return <SettingsPage onNavigate={setPage} />;
      default: return <DashboardPage onNavigate={setPage} />;
    }
  };

  return (
    <AdminLayout activePage={page} onNavigate={setPage}>
      {renderPage()}
    </AdminLayout>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}

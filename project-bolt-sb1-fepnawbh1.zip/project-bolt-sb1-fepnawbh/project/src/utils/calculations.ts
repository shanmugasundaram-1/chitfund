export interface ChitCalcParams {
  chitValue: number;
  members: number;
  duration: number;
  commissionPercent: number;
  auctionMonth: number;
  auctionDiscount: number;
  dividendRule: 'equal' | 'agreement_defined' | 'other';
}

export interface CashFlow {
  date: Date;
  amount: number;
}

export function calculateMonthlyContribution(chitValue: number, members: number): number {
  if (members <= 0) return 0;
  return chitValue / members;
}

export function calculateDiscountPercentage(chitAmount: number, discount: number): number {
  if (chitAmount <= 0) return 0;
  return (discount / chitAmount) * 100;
}

export function calculatePrizeAmount(chitAmount: number, auctionDiscount: number): number {
  return Math.max(0, chitAmount - auctionDiscount);
}

export function calculateForemanCommission(chitAmount: number, commissionPercent: number): number {
  return (chitAmount * commissionPercent) / 100;
}

export function calculateDividendPool(auctionDiscount: number, commission: number): number {
  return Math.max(0, auctionDiscount - commission);
}

export function calculateDividendPerMember(dividendPool: number, members: number): number {
  if (members <= 0) return 0;
  return dividendPool / members;
}

export function calculateRemainingMonths(duration: number, auctionMonth: number): number {
  return Math.max(0, duration - auctionMonth);
}

export function calculateFutureLiability(remainingMonths: number, monthlyContribution: number): number {
  return remainingMonths * monthlyContribution;
}

export function calculateOutstanding(dueAmount: number, paidAmount: number): number {
  return Math.max(0, dueAmount - paidAmount);
}

export function calculatePenalty(outstanding: number, overdueDays: number, penaltyRatePerMonth: number): number {
  if (outstanding <= 0 || overdueDays <= 0) return 0;
  const monthsOverdue = overdueDays / 30;
  return (outstanding * penaltyRatePerMonth * monthsOverdue) / 100;
}

export function calculateTotalPaid(monthlyContribution: number, monthsPaid: number): number {
  return monthlyContribution * monthsPaid;
}

export function calculateTotalReceived(prizeAmount: number, totalDividends: number): number {
  return prizeAmount + totalDividends;
}

export interface FullCalcResult {
  chitValue: number;
  monthlyContribution: number;
  auctionDiscount: number;
  discountPercent: number;
  prizeAmount: number;
  commission: number;
  dividendPool: number;
  dividendPerMember: number;
  remainingMonths: number;
  futureLiability: number;
  totalPaid: number;
  totalReceived: number;
  netCashFlow: number;
}

export function calculateFullScenario(params: ChitCalcParams): FullCalcResult {
  const monthlyContribution = calculateMonthlyContribution(params.chitValue, params.members);
  const discountPercent = calculateDiscountPercentage(params.chitValue, params.auctionDiscount);
  const prizeAmount = calculatePrizeAmount(params.chitValue, params.auctionDiscount);
  const commission = calculateForemanCommission(params.chitValue, params.commissionPercent);
  const dividendPool = calculateDividendPool(params.auctionDiscount, commission);
  const dividendPerMember = calculateDividendPerMember(dividendPool, params.members);
  const remainingMonths = calculateRemainingMonths(params.duration, params.auctionMonth);
  const futureLiability = calculateFutureLiability(remainingMonths, monthlyContribution);
  const totalPaid = calculateTotalPaid(monthlyContribution, params.duration);
  const totalReceived = calculateTotalReceived(prizeAmount, dividendPerMember * params.duration);
  const netCashFlow = totalReceived - totalPaid;

  return {
    chitValue: params.chitValue,
    monthlyContribution,
    auctionDiscount: params.auctionDiscount,
    discountPercent,
    prizeAmount,
    commission,
    dividendPool,
    dividendPerMember,
    remainingMonths,
    futureLiability,
    totalPaid,
    totalReceived,
    netCashFlow,
  };
}

// XIRR calculation
export function calculateXIRR(cashflows: CashFlow[], guess: number = 0.1): number {
  if (cashflows.length < 2) return 0;

  const sorted = [...cashflows].sort((a, b) => a.date.getTime() - b.date.getTime());
  const t0 = sorted[0].date.getTime();

  const years = (t: number) => (t - t0) / (365.25 * 24 * 60 * 60 * 1000);

  const xnpv = (rate: number): number => {
    return sorted.reduce((sum, cf) => {
      return sum + cf.amount / Math.pow(1 + rate, years(cf.date.getTime()));
    }, 0);
  };

  const xnpvDeriv = (rate: number): number => {
    return sorted.reduce((sum, cf) => {
      const y = years(cf.date.getTime());
      return sum - (y * cf.amount) / Math.pow(1 + rate, y + 1);
    }, 0);
  };

  let rate = guess;
  for (let i = 0; i < 100; i++) {
    const f = xnpv(rate);
    const df = xnpvDeriv(rate);
    if (Math.abs(df) < 1e-10) break;
    const newRate = rate - f / df;
    if (Math.abs(newRate - rate) < 1e-7) {
      rate = newRate;
      break;
    }
    rate = newRate;
    if (rate < -0.999) rate = -0.999;
  }

  return rate;
}

// IRR for equal-interval cashflows
export function calculateIRR(cashflows: number[], guess: number = 0.1): number {
  if (cashflows.length < 2) return 0;

  const npv = (rate: number): number => {
    return cashflows.reduce((sum, cf, i) => sum + cf / Math.pow(1 + rate, i), 0);
  };

  const npvDeriv = (rate: number): number => {
    return cashflows.reduce((sum, cf, i) => sum - (i * cf) / Math.pow(1 + rate, i + 1), 0);
  };

  let rate = guess;
  for (let i = 0; i < 100; i++) {
    const f = npv(rate);
    const df = npvDeriv(rate);
    if (Math.abs(df) < 1e-10) break;
    const newRate = rate - f / df;
    if (Math.abs(newRate - rate) < 1e-7) {
      rate = newRate;
      break;
    }
    rate = newRate;
    if (rate < -0.999) rate = -0.999;
  }

  return rate;
}

export function calculateEffectiveMonthlyRate(annualizedRate: number): number {
  return Math.pow(1 + annualizedRate, 1 / 12) - 1;
}

export function calculateAnnualizedRate(monthlyRate: number): number {
  return Math.pow(1 + monthlyRate, 12) - 1;
}

// Build cashflows for a subscriber scenario
export function buildSubscriberCashFlows(
  monthlyContribution: number,
  duration: number,
  prizeAmount: number,
  auctionMonth: number,
  dividendPerMonth: number,
  startDate: Date = new Date(),
): CashFlow[] {
  const flows: CashFlow[] = [];

  for (let m = 1; m <= duration; m++) {
    const d = new Date(startDate.getFullYear(), startDate.getMonth() + m - 1, startDate.getDate());
    // Contribution outflow
    flows.push({ date: d, amount: -monthlyContribution });
    // Dividend inflow (if applicable)
    if (dividendPerMonth > 0 && m > auctionMonth) {
      flows.push({ date: d, amount: dividendPerMonth });
    }
    // Prize inflow at auction month
    if (m === auctionMonth && prizeAmount > 0) {
      flows.push({ date: d, amount: prizeAmount });
    }
  }

  return flows;
}

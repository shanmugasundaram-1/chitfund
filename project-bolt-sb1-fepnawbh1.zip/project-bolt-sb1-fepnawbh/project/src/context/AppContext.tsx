import { createContext, useContext, useState, useEffect, useCallback, type ReactNode } from 'react';
import type { Language, UserRole } from '@/types';
import { translations, type TranslationKey } from '@/i18n/translations';

interface AppContextValue {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey) => string;
  role: UserRole | null;
  setRole: (role: UserRole | null) => void;
  isCustomerPortal: boolean;
  setCustomerPortal: (val: boolean) => void;
}

const AppContext = createContext<AppContextValue | null>(null);

const STORAGE_KEY_LANG = 'slcf_language';
const STORAGE_KEY_ROLE = 'slcf_role';

export function AppProvider({ children }: { children: ReactNode }) {
  const [language, setLanguageState] = useState<Language>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY_LANG);
      if (saved === 'en' || saved === 'ta') return saved;
    }
    return 'en';
  });

  const [role, setRoleState] = useState<UserRole | null>(() => {
    if (typeof window !== 'undefined') {
      const saved = localStorage.getItem(STORAGE_KEY_ROLE);
      if (saved) return saved as UserRole;
    }
    return null;
  });

  const [isCustomerPortal, setCustomerPortal] = useState(false);

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY_LANG, language);
    document.documentElement.lang = language;
    if (language === 'ta') {
      document.documentElement.classList.add('lang-tamil');
    } else {
      document.documentElement.classList.remove('lang-tamil');
    }
  }, [language]);

  useEffect(() => {
    if (role) {
      localStorage.setItem(STORAGE_KEY_ROLE, role);
    } else {
      localStorage.removeItem(STORAGE_KEY_ROLE);
    }
  }, [role]);

  const setLanguage = useCallback((lang: Language) => setLanguageState(lang), []);
  const setRole = useCallback((r: UserRole | null) => {
    setRoleState(r);
    if (r === 'customer') {
      setCustomerPortal(true);
    } else {
      setCustomerPortal(false);
    }
  }, []);

  const t = useCallback((key: TranslationKey) => {
    return translations[language][key] ?? translations.en[key] ?? key;
  }, [language]);

  return (
    <AppContext.Provider value={{ language, setLanguage, t, role, setRole, isCustomerPortal, setCustomerPortal }}>
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error('useApp must be used within AppProvider');
  return ctx;
}

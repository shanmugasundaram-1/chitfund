import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { getNavItemsForRole } from '@/config/navigation';
import { cn } from '@/utils/cn';
import { HelpCircle, Globe, User, LogOut, Menu, X } from 'lucide-react';
import type { TranslationKey } from '@/i18n/translations';

export function Sidebar({ activePage, onNavigate }: { activePage: string; onNavigate: (page: string) => void }) {
  const { t, role, setRole, language, setLanguage } = useApp();
  const [mobileOpen, setMobileOpen] = useState(false);

  if (!role || role === 'customer') return null;

  const items = getNavItemsForRole(role);

  const handleNav = (page: string) => {
    onNavigate(page);
    setMobileOpen(false);
  };

  const handleLogout = () => {
    setRole(null);
  };

  return (
    <>
      {/* Mobile toggle */}
      <button
        onClick={() => setMobileOpen(!mobileOpen)}
        className="lg:hidden fixed top-3 left-3 z-50 p-2 rounded-lg bg-white border border-ink-200 shadow-card"
      >
        {mobileOpen ? <X size={20} /> : <Menu size={20} />}
      </button>

      {/* Overlay */}
      {mobileOpen && (
        <div className="lg:hidden fixed inset-0 z-30 bg-ink-950/30" onClick={() => setMobileOpen(false)} />
      )}

      <aside className={cn(
        'fixed lg:sticky top-0 left-0 z-40 h-screen w-64 bg-white border-r border-ink-200 flex flex-col transition-transform duration-200',
        mobileOpen ? 'translate-x-0' : '-translate-x-full lg:translate-x-0',
      )}>
        {/* Logo */}
        <div className="px-5 py-5 border-b border-ink-200">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-brand-700 flex items-center justify-center flex-shrink-0">
              <span className="text-gold-200 font-bold text-lg font-display">L</span>
            </div>
            <div className="min-w-0">
              <p className="font-display font-bold text-sm text-ink-900 leading-tight truncate">{t('brandName')}</p>
              <p className="text-xs text-ink-500 truncate">{t('brandSubtitle')}</p>
            </div>
          </div>
        </div>

        {/* Nav */}
        <nav className="flex-1 overflow-y-auto px-3 py-4 space-y-1">
          {items.map(item => {
            const Icon = item.icon;
            return (
              <button
                key={item.id}
                onClick={() => handleNav(item.id)}
                className={cn('nav-item w-full', activePage === item.id && 'nav-item-active')}
              >
                <Icon size={18} className="flex-shrink-0" />
                <span className="truncate">{t(item.labelKey)}</span>
              </button>
            );
          })}
        </nav>

        {/* Bottom */}
        <div className="px-3 py-4 border-t border-ink-200 space-y-1">
          <button className="nav-item w-full">
            <HelpCircle size={18} className="flex-shrink-0" />
            <span>{t('help')}</span>
          </button>
          <button onClick={() => setLanguage(language === 'en' ? 'ta' : 'en')} className="nav-item w-full">
            <Globe size={18} className="flex-shrink-0" />
            <span>{t('language')}: {language === 'en' ? 'English' : 'தமிழ்'}</span>
          </button>
          <button className="nav-item w-full">
            <User size={18} className="flex-shrink-0" />
            <span>{t('userProfile')}</span>
          </button>
          <button onClick={handleLogout} className="nav-item w-full text-red-600 hover:bg-red-50 hover:text-red-700">
            <LogOut size={18} className="flex-shrink-0" />
            <span>{t('logout')}</span>
          </button>
        </div>
      </aside>
    </>
  );
}

export function TopBar({ title, subtitle }: { title: string; subtitle?: string }) {
  const { t, language, setLanguage, role, setRole } = useApp();

  const roleLabels: Record<string, TranslationKey> = {
    super_admin: 'superAdmin',
    branch_manager: 'branchManager',
    accountant: 'accountant',
    collection_staff: 'collectionStaff',
    auction_staff: 'auctionStaff',
  };

  return (
    <header className="sticky top-0 z-20 bg-white border-b border-ink-200 px-4 lg:px-6 py-3.5 flex items-center justify-between gap-4">
      <div className="min-w-0 flex-1">
        <h1 className="text-lg lg:text-xl font-bold text-ink-900 truncate">{title}</h1>
        {subtitle && <p className="text-xs lg:text-sm text-ink-500 truncate">{subtitle}</p>}
      </div>

      <div className="flex items-center gap-2 lg:gap-3 flex-shrink-0">
        {/* Language switcher */}
        <div className="flex items-center rounded-lg border border-ink-200 overflow-hidden">
          <button
            onClick={() => setLanguage('en')}
            className={cn('px-3 py-1.5 text-sm font-medium transition-colors', language === 'en' ? 'bg-brand-700 text-white' : 'text-ink-600 hover:bg-ink-100')}
          >
            English
          </button>
          <button
            onClick={() => setLanguage('ta')}
            className={cn('px-3 py-1.5 text-sm font-medium transition-colors', language === 'ta' ? 'bg-brand-700 text-white' : 'text-ink-600 hover:bg-ink-100')}
          >
            தமிழ்
          </button>
        </div>

        {/* Role indicator */}
        {role && role !== 'customer' && (
          <div className="hidden sm:flex items-center gap-2 px-3 py-1.5 rounded-lg bg-ink-100">
            <div className="w-7 h-7 rounded-full bg-brand-700 text-white flex items-center justify-center text-xs font-bold">
              {role === 'super_admin' ? 'SA' : role === 'branch_manager' ? 'BM' : role === 'accountant' ? 'AC' : role === 'collection_staff' ? 'CS' : 'AS'}
            </div>
            <span className="text-sm font-medium text-ink-700">{t(roleLabels[role] || 'superAdmin')}</span>
          </div>
        )}

        <button
          onClick={() => setRole(null)}
          className="btn-ghost px-2.5 py-2"
          title={t('logout')}
        >
          <LogOut size={18} />
        </button>
      </div>
    </header>
  );
}

export function AdminLayout({ activePage, onNavigate, children }: { activePage: string; onNavigate: (page: string) => void; children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-ink-50">
      <Sidebar activePage={activePage} onNavigate={onNavigate} />
      <div className="flex-1 flex flex-col min-w-0">
        {children}
      </div>
    </div>
  );
}

import type { ReactNode } from 'react';
import { useState } from 'react';
import { cn } from '@/utils/cn';

export function Card({ children, className, hover }: { children: ReactNode; className?: string; hover?: boolean }) {
  return <div className={cn(hover ? 'card-hover' : 'card', className)}>{children}</div>;
}

export function CardHeader({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex items-start justify-between px-5 pt-5 pb-3">
      <div>
        <h3 className="section-title">{title}</h3>
        {subtitle && <p className="text-sm text-ink-500 mt-0.5">{subtitle}</p>}
      </div>
      {action}
    </div>
  );
}

export function CardBody({ children, className }: { children: ReactNode; className?: string }) {
  return <div className={cn('px-5 pb-5', className)}>{children}</div>;
}

type BadgeVariant = 'success' | 'warning' | 'danger' | 'info' | 'neutral';

const badgeClasses: Record<BadgeVariant, string> = {
  success: 'badge-success',
  warning: 'badge-warning',
  danger: 'badge-danger',
  info: 'badge-info',
  neutral: 'badge-neutral',
};

export function Badge({ variant = 'neutral', children }: { variant?: BadgeVariant; children: ReactNode }) {
  return <span className={badgeClasses[variant]}>{children}</span>;
}

export function StatusBadge({ status }: { status: string }) {
  const map: Record<string, BadgeVariant> = {
    active: 'success', verified: 'success', paid: 'success', approved: 'success', completed: 'success', distributed: 'success', matched: 'success', prized: 'success',
    upcoming: 'info', scheduled: 'info', pending: 'warning', pending_approval: 'warning', partial: 'warning', under_review: 'warning', needs_review: 'warning', submitted: 'warning', draft: 'neutral',
    overdue: 'danger', defaulted: 'danger', rejected: 'danger', failed: 'danger', expired: 'danger', suspended: 'warning', cancelled: 'danger',
    non_prized: 'neutral', closed: 'neutral', transferred: 'info', unmatched: 'danger',
  };
  const variant = map[status] || 'neutral';
  return <Badge variant={variant}>{status.replace(/_/g, ' ').replace(/\b\w/g, c => c.toUpperCase())}</Badge>;
}

export function Button({ children, onClick, variant = 'primary', className, disabled, type = 'button' }: {
  children: ReactNode;
  onClick?: () => void;
  variant?: 'primary' | 'secondary' | 'ghost' | 'gold' | 'danger';
  className?: string;
  disabled?: boolean;
  type?: 'button' | 'submit';
}) {
  const variants = {
    primary: 'btn-primary',
    secondary: 'btn-secondary',
    ghost: 'btn-ghost',
    gold: 'btn-gold',
    danger: 'btn-danger',
  };
  return (
    <button type={type} onClick={onClick} disabled={disabled} className={cn(variants[variant], className)}>
      {children}
    </button>
  );
}

export function Input({ label, value, onChange, type = 'text', placeholder, error, required, disabled, min, max }: {
  label?: string;
  value: string | number;
  onChange: (val: string) => void;
  type?: string;
  placeholder?: string;
  error?: string;
  required?: boolean;
  disabled?: boolean;
  min?: number;
  max?: number;
}) {
  return (
    <div>
      {label && <label className="label">{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>}
      <input
        type={type}
        value={value}
        onChange={(e) => onChange(e.target.value)}
        placeholder={placeholder}
        disabled={disabled}
        min={min}
        max={max}
        className={cn('input', error && 'border-red-400 focus:ring-red-200')}
      />
      {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
    </div>
  );
}

export function Select({ label, value, onChange, options, error, required, disabled }: {
  label?: string;
  value: string;
  onChange: (val: string) => void;
  options: { value: string; label: string }[];
  error?: string;
  required?: boolean;
  disabled?: boolean;
}) {
  return (
    <div>
      {label && <label className="label">{label}{required && <span className="text-red-500 ml-0.5">*</span>}</label>}
      <select
        value={value}
        onChange={(e) => onChange(e.target.value)}
        disabled={disabled}
        className={cn('input', error && 'border-red-400 focus:ring-red-200')}
      >
        {options.map(opt => <option key={opt.value} value={opt.value}>{opt.label}</option>)}
      </select>
      {error && <p className="text-xs text-red-500 mt-1">{error}</p>}
    </div>
  );
}

export function Modal({ open, onClose, title, children, size = 'md' }: {
  open: boolean;
  onClose: () => void;
  title: string;
  children: ReactNode;
  size?: 'sm' | 'md' | 'lg' | 'xl';
}) {
  if (!open) return null;
  const sizes = { sm: 'max-w-md', md: 'max-w-lg', lg: 'max-w-2xl', xl: 'max-w-4xl' };
  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-ink-950/40 backdrop-blur-sm" onClick={onClose}>
      <div className={cn('card w-full max-h-[90vh] overflow-y-auto', sizes[size])} onClick={(e) => e.stopPropagation()}>
        <div className="flex items-center justify-between px-5 py-4 border-b border-ink-200 sticky top-0 bg-white z-10">
          <h3 className="section-title">{title}</h3>
          <button onClick={onClose} className="text-ink-400 hover:text-ink-900 p-1 rounded-lg hover:bg-ink-100">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M18 6L6 18M6 6l12 12"/></svg>
          </button>
        </div>
        <div className="p-5">{children}</div>
      </div>
    </div>
  );
}

export function EmptyState({ title, subtitle, action }: { title: string; subtitle?: string; action?: ReactNode }) {
  return (
    <div className="flex flex-col items-center justify-center py-16 px-4 text-center">
      <div className="w-16 h-16 rounded-full bg-ink-100 flex items-center justify-center mb-4">
        <svg width="28" height="28" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.5" className="text-ink-400">
          <path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4M7 10l5 5 5-5M12 15V3"/>
        </svg>
      </div>
      <h3 className="text-base font-semibold text-ink-700 mb-1">{title}</h3>
      {subtitle && <p className="text-sm text-ink-500 mb-4">{subtitle}</p>}
      {action}
    </div>
  );
}

export function InfoNote({ children, variant = 'info' }: { children: ReactNode; variant?: 'info' | 'warning' }) {
  const styles = {
    info: 'bg-brand-50 border-brand-200 text-brand-800',
    warning: 'bg-gold-50 border-gold-200 text-gold-800',
  };
  return (
    <div className={cn('rounded-lg border px-4 py-3 text-sm flex items-start gap-2', styles[variant])}>
      <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className="mt-0.5 flex-shrink-0">
        <circle cx="12" cy="12" r="10"/><path d="M12 16v-4M12 8h.01"/>
      </svg>
      <span>{children}</span>
    </div>
  );
}

export function CalculationRow({ label, value, bold, indent }: { label: string; value: string; bold?: boolean; indent?: boolean }) {
  return (
    <div className={cn('flex items-center justify-between py-2', indent && 'pl-4', bold && 'border-t border-ink-200 mt-1 pt-3 font-semibold')}>
      <span className={cn('text-sm', bold ? 'text-ink-900 font-semibold' : 'text-ink-600')}>{label}</span>
      <span className={cn('text-sm tabular-nums', bold ? 'text-ink-900 font-semibold' : 'text-ink-800')}>{value}</span>
    </div>
  );
}

export function HowCalculated({ children }: { children: ReactNode }) {
  const [open, setOpen] = useState(false);
  return (
    <div className="mt-3">
      <button
        onClick={() => setOpen(!open)}
        className="flex items-center gap-1.5 text-sm text-brand-700 hover:text-brand-800 font-medium"
      >
        <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><circle cx="12" cy="12" r="10"/><path d="M9.09 9a3 3 0 015.83 1c0 2-3 3-3 3M12 17h.01"/></svg>
        How was this calculated?
        <svg width="12" height="12" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" className={cn('transition-transform', open && 'rotate-180')}><path d="M6 9l6 6 6-6"/></svg>
      </button>
      {open && <div className="mt-2 p-3 bg-ink-50 rounded-lg text-sm text-ink-600 border border-ink-200">{children}</div>}
    </div>
  );
}

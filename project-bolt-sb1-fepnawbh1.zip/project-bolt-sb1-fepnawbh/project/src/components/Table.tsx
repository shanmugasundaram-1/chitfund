import type { ReactNode } from 'react';
import { cn } from '@/utils/cn';

export interface Column<T> {
  key: string;
  header: string;
  render: (row: T) => ReactNode;
  className?: string;
  align?: 'left' | 'right' | 'center';
}

export function DataTable<T extends { id: string }>({ columns, data, onRowClick, emptyState }: {
  columns: Column<T>[];
  data: T[];
  onRowClick?: (row: T) => void;
  emptyState?: ReactNode;
}) {
  if (data.length === 0 && emptyState) {
    return <>{emptyState}</>;
  }

  return (
    <div className="overflow-x-auto">
      <table className="w-full">
        <thead>
          <tr className="border-b border-ink-200">
            {columns.map(col => (
              <th
                key={col.key}
                className={cn(
                  'px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap',
                  col.align === 'right' && 'text-right',
                  col.align === 'center' && 'text-center',
                  !col.align && 'text-left',
                )}
              >
                {col.header}
              </th>
            ))}
          </tr>
        </thead>
        <tbody>
          {data.map((row) => (
            <tr
              key={row.id}
              onClick={() => onRowClick?.(row)}
              className={cn('border-b border-ink-100 last:border-0', onRowClick && 'cursor-pointer table-row-hover')}
            >
              {columns.map(col => (
                <td
                  key={col.key}
                  className={cn(
                    'px-4 py-3 text-sm text-ink-700 whitespace-nowrap',
                    col.align === 'right' && 'text-right tabular-nums',
                    col.align === 'center' && 'text-center',
                    col.className,
                  )}
                >
                  {col.render(row)}
                </td>
              ))}
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

export function KPICard({ label, value, trend, icon, accent }: {
  label: string;
  value: string;
  trend?: { value: string; positive: boolean };
  icon?: ReactNode;
  accent?: 'green' | 'gold';
}) {
  return (
    <div className="card p-5">
      <div className="flex items-start justify-between mb-3">
        <p className="kpi-label">{label}</p>
        {icon && (
          <div className={cn(
            'w-9 h-9 rounded-lg flex items-center justify-center',
            accent === 'gold' ? 'bg-gold-100 text-gold-700' : 'bg-brand-100 text-brand-700',
          )}>
            {icon}
          </div>
        )}
      </div>
      <p className="text-2xl font-bold text-ink-900 tabular-nums">{value}</p>
      {trend && (
        <div className="flex items-center gap-1.5 mt-2">
          <span className={cn('text-xs font-medium', trend.positive ? 'text-brand-600' : 'text-red-500')}>
            {trend.positive ? '↑' : '↓'} {trend.value}
          </span>
          <span className="text-xs text-ink-400">vs previous month</span>
        </div>
      )}
    </div>
  );
}

export function SimpleBarChart({ data, height = 200 }: {
  data: { label: string; value1: number; value2: number; label1: string; label2: string };
  height?: number;
}) {
  const max = Math.max(...data.value1, ...data.value2) * 1.1 || 1;
  return (
    <div>
      <div className="flex items-center gap-4 mb-3 text-xs text-ink-500">
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-brand-300"></span>{data.label1}</span>
        <span className="flex items-center gap-1.5"><span className="w-3 h-3 rounded bg-brand-600"></span>{data.label2}</span>
      </div>
      <div className="flex items-end justify-between gap-2" style={{ height }}>
        {data.label.map((_, i) => (
          <div key={i} className="flex-1 flex flex-col items-center gap-1">
            <div className="w-full flex items-end justify-center gap-1" style={{ height: height - 30 }}>
              <div className="flex-1 bg-brand-300 rounded-t" style={{ height: `${(data.value1[i] / max) * 100}%` }} />
              <div className="flex-1 bg-brand-600 rounded-t" style={{ height: `${(data.value2[i] / max) * 100}%` }} />
            </div>
            <span className="text-xs text-ink-500">{data.label[i]}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

export function ProgressBar({ value, max, variant = 'brand' }: { value: number; max: number; variant?: 'brand' | 'gold' | 'red' }) {
  const pct = Math.min(100, (value / max) * 100);
  const colors = { brand: 'bg-brand-600', gold: 'bg-gold-500', red: 'bg-red-500' };
  return (
    <div className="w-full h-2 bg-ink-100 rounded-full overflow-hidden">
      <div className={cn('h-full rounded-full transition-all', colors[variant])} style={{ width: `${pct}%` }} />
    </div>
  );
}

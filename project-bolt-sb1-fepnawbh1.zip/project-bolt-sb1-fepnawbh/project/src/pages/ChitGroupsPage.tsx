import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { TopBar } from '@/components/Layout';
import { Card, CardHeader, CardBody, StatusBadge, Button, Modal, Input, Select, EmptyState, InfoNote, CalculationRow } from '@/components/ui';
import { formatINR, formatDate } from '@/utils/format';
import { chitGroups, subscribers, branches } from '@/data/mockData';
import { calculateMonthlyContribution } from '@/utils/calculations';
import { Plus, Search, Eye, Users, Calendar, Percent, Coins } from 'lucide-react';
import type { ChitGroup } from '@/types';

export function ChitGroupsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [showCreate, setShowCreate] = useState(false);
  const [step, setStep] = useState(1);
  const [selectedChit, setSelectedChit] = useState<ChitGroup | null>(null);
  const [form, setForm] = useState({
    name: '', chitValue: '', members: '', duration: '', startDate: '', branch: 'Chennai HQ',
    auctionMethod: 'open_auction', maxDiscount: '30', commission: '5',
    dividendRule: 'equal', tieBreak: 'Manual review according to chit agreement',
    dueDate: '5', gracePeriod: '5', penaltyRate: '2',
  });

  const filtered = chitGroups.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) || c.id.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const chitGroupSubscribers = selectedChit ? subscribers.filter(s => s.chitGroupId === selectedChit.id) : [];
  const previewContribution = form.chitValue && form.members ? calculateMonthlyContribution(Number(form.chitValue), Number(form.members)) : 0;

  const handleCreate = () => { setShowCreate(false); setStep(1); };
  const closeModal = () => { setShowCreate(false); setStep(1); };

  return (
    <div>
      <TopBar title={t('chitGroups')} subtitle={`${chitGroups.length} ${t('chitGroups').toLowerCase()}`} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 items-stretch sm:items-center justify-between">
          <div className="flex gap-3 flex-1 max-w-xl">
            <div className="relative flex-1">
              <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
              <input className="input pl-9" placeholder={t('searchPlaceholder')} value={search} onChange={e => setSearch(e.target.value)} />
            </div>
            <select className="input w-auto" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
              <option value="all">{t('all')}</option>
              <option value="active">{t('active')}</option>
              <option value="upcoming">{t('upcoming')}</option>
              <option value="completed">{t('completed')}</option>
              <option value="suspended">{t('suspended')}</option>
              <option value="closed">{t('closed')}</option>
            </select>
          </div>
          <Button onClick={() => setShowCreate(true)}><Plus size={16} /> {t('newChitGroup')}</Button>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: t('chitId'), align: 'left' }, { label: t('chitName'), align: 'left' },
                    { label: t('chitValue'), align: 'right' }, { label: t('members'), align: 'center' },
                    { label: t('duration'), align: 'center' }, { label: t('monthlyContribution'), align: 'right' },
                    { label: t('currentMonth'), align: 'center' }, { label: t('commission'), align: 'center' },
                    { label: t('status'), align: 'center' }, { label: t('nextAuction'), align: 'left' },
                    { label: '', align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(c => (
                  <tr key={c.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50 cursor-pointer" onClick={() => setSelectedChit(c)}>
                    <td className="px-4 py-3 text-sm font-medium text-brand-700">{c.id}</td>
                    <td className="px-4 py-3 text-sm font-medium text-ink-900">{c.name}</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(c.chitValue)}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">{c.members}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">{c.duration}m</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(c.monthlyContribution)}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">M{c.currentMonth}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">{c.commissionPercent}%</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={c.status} /></td>
                    <td className="px-4 py-3 text-sm text-ink-600">{c.nextAuctionDate ? formatDate(c.nextAuctionDate) : '—'}</td>
                    <td className="px-4 py-3 text-center"><button onClick={(e) => { e.stopPropagation(); setSelectedChit(c); }} className="text-brand-700 hover:text-brand-800"><Eye size={16} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <EmptyState title="No chit groups found" subtitle="Try adjusting your filters" />}
        </Card>
      </div>

      {/* Create Chit Group Modal */}
      <Modal open={showCreate} onClose={closeModal} title={t('createChitGroup')} size="lg">
        <div className="flex items-center gap-2 mb-6">
          {[1, 2, 3, 4].map(s => (
            <div key={s} className="flex items-center gap-2 flex-1">
              <div className={`w-7 h-7 rounded-full flex items-center justify-center text-xs font-bold ${step >= s ? 'bg-brand-700 text-white' : 'bg-ink-100 text-ink-400'}`}>{s}</div>
              {s < 4 && <div className={`h-0.5 flex-1 ${step > s ? 'bg-brand-600' : 'bg-ink-200'}`} />}
            </div>
          ))}
        </div>
        <p className="text-sm text-ink-500 mb-4">{t('step')} {step} {t('of')} 4</p>

        {step === 1 && (
          <div className="space-y-4">
            <h3 className="font-semibold text-ink-900">{t('basicInformation')}</h3>
            <Input label={t('chitName')} value={form.name} onChange={v => setForm({...form, name: v})} required placeholder="e.g. Lakshmi Gold 10L" />
            <div className="grid grid-cols-2 gap-4">
              <Input label={t('chitValue')} type="number" value={form.chitValue} onChange={v => setForm({...form, chitValue: v})} required placeholder="1000000" />
              <Input label={t('numberOfSubscribers')} type="number" value={form.members} onChange={v => setForm({...form, members: v})} required placeholder="20" />
              <Input label={t('duration')} type="number" value={form.duration} onChange={v => setForm({...form, duration: v})} required placeholder="20" />
              <Input label={t('startDate')} type="date" value={form.startDate} onChange={v => setForm({...form, startDate: v})} required />
              <Select label={t('branch')} value={form.branch} onChange={v => setForm({...form, branch: v})} options={branches.map(b => ({ value: b.name, label: b.name }))} />
            </div>
            {previewContribution > 0 && (
              <div className="bg-brand-50 border border-brand-200 rounded-lg p-4">
                <p className="text-xs font-semibold text-brand-700 uppercase tracking-wide mb-2">{t('calculationPreview')}</p>
                <div className="flex items-center justify-between">
                  <span className="text-sm text-ink-600">{t('monthlyContribution')} = {t('chitValue')} / {t('numberOfSubscribers')}</span>
                  <span className="text-lg font-bold text-brand-800 tabular-nums">{formatINR(previewContribution)}</span>
                </div>
              </div>
            )}
            <div className="flex justify-end"><Button onClick={() => setStep(2)} disabled={!form.name || !form.chitValue || !form.members || !form.duration}>{t('next')} →</Button></div>
          </div>
        )}

        {step === 2 && (
          <div className="space-y-4">
            <h3 className="font-semibold text-ink-900">{t('auctionConfiguration')}</h3>
            <Select label={t('auctionMethod')} value={form.auctionMethod} onChange={v => setForm({...form, auctionMethod: v})}
              options={[{ value: 'open_auction', label: t('openAuction') }, { value: 'sealed_bid', label: t('sealedBid') }]} />
            <div className="grid grid-cols-2 gap-4">
              <Input label={t('maximumDiscount') + ' %'} type="number" value={form.maxDiscount} onChange={v => setForm({...form, maxDiscount: v})} />
              <Input label={t('commission') + ' %'} type="number" value={form.commission} onChange={v => setForm({...form, commission: v})} />
            </div>
            <Select label={t('dividendDistributionRule')} value={form.dividendRule} onChange={v => setForm({...form, dividendRule: v})}
              options={[{ value: 'equal', label: t('equalDistribution') }, { value: 'agreement_defined', label: t('agreementDefined') }, { value: 'other', label: t('otherPermittedRule') }]} />
            <Input label={t('tieBreakRule')} value={form.tieBreak} onChange={v => setForm({...form, tieBreak: v})} />
            <InfoNote>{t('commissionNote')}</InfoNote>
            <div className="flex justify-between"><Button variant="secondary" onClick={() => setStep(1)}>← {t('previous')}</Button><Button onClick={() => setStep(3)}>{t('next')} →</Button></div>
          </div>
        )}

        {step === 3 && (
          <div className="space-y-4">
            <h3 className="font-semibold text-ink-900">{t('paymentConfiguration')}</h3>
            <div className="grid grid-cols-2 gap-4">
              <Input label="Due Date (day of month)" type="number" value={form.dueDate} onChange={v => setForm({...form, dueDate: v})} />
              <Input label={t('gracePeriod') + ' (days)'} type="number" value={form.gracePeriod} onChange={v => setForm({...form, gracePeriod: v})} />
              <Input label={t('penaltyConfig') + ' %'} type="number" value={form.penaltyRate} onChange={v => setForm({...form, penaltyRate: v})} />
            </div>
            <div>
              <label className="label">{t('paymentModes')}</label>
              <div className="flex flex-wrap gap-2">
                {['Cash', 'UPI', 'Bank Transfer', 'Cheque', 'Auto Debit'].map(mode => (
                  <label key={mode} className="flex items-center gap-1.5 px-3 py-2 rounded-lg border border-ink-200 cursor-pointer hover:bg-ink-50">
                    <input type="checkbox" defaultChecked className="rounded" /> <span className="text-sm">{mode}</span>
                  </label>
                ))}
              </div>
            </div>
            <InfoNote variant="warning">{t('penaltyNote')}</InfoNote>
            <div className="flex justify-between"><Button variant="secondary" onClick={() => setStep(2)}>← {t('previous')}</Button><Button onClick={() => setStep(4)}>{t('next')} →</Button></div>
          </div>
        )}

        {step === 4 && (
          <div className="space-y-4">
            <h3 className="font-semibold text-ink-900">{t('reviewCreate')}</h3>
            <div className="bg-ink-50 rounded-lg p-4 space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-ink-500">{t('chitName')}</span><span className="font-medium text-ink-900">{form.name || '—'}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('chitValue')}</span><span className="font-medium text-ink-900">{form.chitValue ? formatINR(Number(form.chitValue)) : '—'}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('numberOfSubscribers')}</span><span className="font-medium text-ink-900">{form.members || '—'}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('duration')}</span><span className="font-medium text-ink-900">{form.duration || '—'} months</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('monthlyContribution')}</span><span className="font-bold text-brand-700">{previewContribution > 0 ? formatINR(previewContribution) : '—'}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('commission')}</span><span className="font-medium text-ink-900">{form.commission}%</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('branch')}</span><span className="font-medium text-ink-900">{form.branch}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('auctionMethod')}</span><span className="font-medium text-ink-900">{form.auctionMethod === 'open_auction' ? t('openAuction') : t('sealedBid')}</span></div>
            </div>
            <div className="flex justify-between"><Button variant="secondary" onClick={() => setStep(3)}>← {t('previous')}</Button><Button onClick={handleCreate}>{t('create')}</Button></div>
          </div>
        )}
      </Modal>

      {/* Chit Group Detail Modal */}
      <Modal open={!!selectedChit} onClose={() => setSelectedChit(null)} title={selectedChit?.name || ''} size="xl">
        {selectedChit && (
          <div className="space-y-5">
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('chitId')}</p><p className="font-bold text-ink-900">{selectedChit.id}</p></div>
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('chitValue')}</p><p className="font-bold text-ink-900">{formatINR(selectedChit.chitValue)}</p></div>
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('monthlyContribution')}</p><p className="font-bold text-ink-900">{formatINR(selectedChit.monthlyContribution)}</p></div>
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('status')}</p><div className="pt-1"><StatusBadge status={selectedChit.status} /></div></div>
            </div>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 text-sm">
              <div><span className="text-ink-500">{t('members')}:</span> <span className="font-medium text-ink-900">{selectedChit.members}</span></div>
              <div><span className="text-ink-500">{t('duration')}:</span> <span className="font-medium text-ink-900">{selectedChit.duration} months</span></div>
              <div><span className="text-ink-500">{t('currentMonth')}:</span> <span className="font-medium text-ink-900">M{selectedChit.currentMonth}</span></div>
              <div><span className="text-ink-500">{t('commission')}:</span> <span className="font-medium text-ink-900">{selectedChit.commissionPercent}%</span></div>
              <div><span className="text-ink-500">{t('branch')}:</span> <span className="font-medium text-ink-900">{selectedChit.branch}</span></div>
              <div><span className="text-ink-500">{t('startDate')}:</span> <span className="font-medium text-ink-900">{formatDate(selectedChit.startDate)}</span></div>
              <div><span className="text-ink-500">{t('nextAuction')}:</span> <span className="font-medium text-ink-900">{selectedChit.nextAuctionDate ? formatDate(selectedChit.nextAuctionDate) : '—'}</span></div>
              <div><span className="text-ink-500">{t('auctionMethod')}:</span> <span className="font-medium text-ink-900">{selectedChit.auctionMethod === 'open_auction' ? t('openAuction') : t('sealedBid')}</span></div>
            </div>
            <div>
              <h4 className="font-semibold text-ink-900 mb-3">{t('subscribers')} ({chitGroupSubscribers.length})</h4>
              <div className="max-h-60 overflow-y-auto border border-ink-200 rounded-lg">
                <table className="w-full">
                  <thead className="sticky top-0 bg-ink-50">
                    <tr className="border-b border-ink-200">
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-left">ID</th>
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-left">{t('name')}</th>
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-center">{t('ticketNo')}</th>
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-center">{t('status')}</th>
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-right">{t('totalPaid')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {chitGroupSubscribers.map(s => (
                      <tr key={s.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50 cursor-pointer" onClick={() => onNavigate('subscribers')}>
                        <td className="px-3 py-2 text-sm text-brand-700">{s.id}</td>
                        <td className="px-3 py-2 text-sm text-ink-900">{s.name}</td>
                        <td className="px-3 py-2 text-sm text-ink-600 text-center">#{s.ticketNo}</td>
                        <td className="px-3 py-2 text-center"><StatusBadge status={s.status} /></td>
                        <td className="px-3 py-2 text-sm text-ink-900 text-right tabular-nums">{formatINR(s.totalPaid)}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

import { useApp } from '@/context/AppContext';
import { TopBar } from '@/components/Layout';
import { Card, CardHeader, CardBody, StatusBadge, Button } from '@/components/ui';
import { KPICard, SimpleBarChart } from '@/components/Table';
import { formatINR, formatDate } from '@/utils/format';
import {
  collectionOverview, outstandingAging, dashboardAlerts, payments, auctions, dashboardKPIs,
} from '@/data/mockData';
import {
  Users, Users2, Wallet, AlertCircle, HandCoins, Gavel, Trophy, Coins, ArrowUpRight, Bell,
} from 'lucide-react';
import type { TranslationKey } from '@/i18n/translations';

export function DashboardPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t, language } = useApp();

  const recentPayments = payments.slice(0, 6);
  const completedAuctions = auctions.filter(a => a.status === 'completed').slice(0, 5);
  const upcomingAuctions = auctions.filter(a => a.status === 'scheduled').slice(0, 5);

  const chartData = {
    label: collectionOverview.map(d => d.month),
    value1: collectionOverview.map(d => d.expected),
    value2: collectionOverview.map(d => d.actual),
    label1: t('expectedCollection'),
    label2: t('actualCollection'),
  };

  return (
    <div>
      <TopBar title={t('dashboard')} subtitle={language === 'ta' ? 'மேலாண்மை கண்ணோட்டம்' : 'Management overview'} />

      <div className="p-4 lg:p-6 space-y-6">
        {/* KPI Cards */}
        <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-4">
          <KPICard label={t('activeChitGroups')} value={String(dashboardKPIs.activeChitGroups)} icon={<Users size={18} />} />
          <KPICard label={t('activeSubscribers')} value={dashboardKPIs.activeSubscribers.toLocaleString('en-IN')} icon={<Users2 size={18} />} />
          <KPICard label={t('monthlyCollection')} value={formatINR(dashboardKPIs.monthlyCollection, { compact: true })} trend={{ value: `+${dashboardKPIs.monthlyCollectionTrend}%`, positive: true }} icon={<Wallet size={18} />} />
          <KPICard label={t('outstandingAmt')} value={formatINR(dashboardKPIs.outstanding, { compact: true })} icon={<AlertCircle size={18} />} accent="gold" />
          <KPICard label={t('todaysCollection')} value={formatINR(dashboardKPIs.todaysCollection, { compact: true })} icon={<HandCoins size={18} />} />
          <KPICard label={t('upcomingAuctions')} value={String(dashboardKPIs.upcomingAuctions)} icon={<Gavel size={18} />} accent="gold" />
          <KPICard label={t('prizedSubscribers')} value={dashboardKPIs.prizedSubscribers.toLocaleString('en-IN')} icon={<Trophy size={18} />} />
          <KPICard label={t('dividendDistributed')} value={formatINR(dashboardKPIs.dividendDistributed, { compact: true })} icon={<Coins size={18} />} />
        </div>

        {/* Charts row */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader title={t('collectionOverview')} subtitle={language === 'ta' ? 'கடந்த 6 மாதங்கள்' : 'Last 6 months'} />
            <CardBody>
              <SimpleBarChart data={chartData} />
            </CardBody>
          </Card>

          <Card>
            <CardHeader title={t('outstandingOverview')} />
            <CardBody>
              <div className="space-y-4">
                {outstandingAging.map((item) => (
                  <div key={item.labelKey}>
                    <div className="flex items-center justify-between mb-1.5">
                      <span className="text-sm text-ink-600">{t(item.labelKey as TranslationKey)}</span>
                      <span className="text-sm font-semibold text-ink-900 tabular-nums">{formatINR(item.amount, { compact: true })}</span>
                    </div>
                    <div className="w-full h-2 bg-ink-100 rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full ${item.labelKey === 'current' ? 'bg-brand-500' : item.labelKey === 'days1to7' ? 'bg-gold-400' : item.labelKey === 'days8to30' ? 'bg-gold-600' : 'bg-red-500'}`}
                        style={{ width: `${(item.amount / 2180000) * 100}%` }}
                      />
                    </div>
                    <p className="text-xs text-ink-400 mt-1">{item.count} accounts</p>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>

        {/* Upcoming auctions + alerts */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          <Card className="lg:col-span-2">
            <CardHeader
              title={t('upcomingAuctions')}
              action={<Button variant="ghost" onClick={() => onNavigate('auctions')}>{t('viewAll')} →</Button>}
            />
            <CardBody className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-ink-200">
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-left">{t('chitGroup')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-left">{t('date')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-right">{t('chitValue')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-center">{t('members')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-center">{t('status')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {upcomingAuctions.map((auc) => (
                      <tr key={auc.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50 cursor-pointer" onClick={() => onNavigate('auctions')}>
                        <td className="px-4 py-3 text-sm font-medium text-ink-900">{auc.chitGroupName}</td>
                        <td className="px-4 py-3 text-sm text-ink-600">{formatDate(auc.date)}</td>
                        <td className="px-4 py-3 text-sm text-ink-700 text-right tabular-nums">{formatINR(auc.chitAmount, { compact: true })}</td>
                        <td className="px-4 py-3 text-sm text-ink-600 text-center">{auc.eligibleSubscribers}</td>
                        <td className="px-4 py-3 text-center"><StatusBadge status={auc.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title={t('alerts')} />
            <CardBody>
              <div className="space-y-3">
                {dashboardAlerts.map((alert, i) => (
                  <div key={i} className={`flex items-start gap-3 p-3 rounded-lg border ${
                    alert.type === 'danger' ? 'bg-red-50 border-red-200' : alert.type === 'warning' ? 'bg-gold-50 border-gold-200' : 'bg-blue-50 border-blue-200'
                  }`}>
                    <Bell size={16} className={`mt-0.5 flex-shrink-0 ${alert.type === 'danger' ? 'text-red-600' : alert.type === 'warning' ? 'text-gold-700' : 'text-blue-600'}`} />
                    <p className="text-sm text-ink-700">{language === 'ta' ? alert.messageTa : alert.message}</p>
                  </div>
                ))}
              </div>
            </CardBody>
          </Card>
        </div>

        {/* Recent payments + auction winners */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader title={t('recentPayments')} action={<Button variant="ghost" onClick={() => onNavigate('payments')}>{t('viewAll')} →</Button>} />
            <CardBody className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-ink-200">
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-left">{t('receiptNo')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-left">{t('subscriber')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-right">{t('amount')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-left">{t('paymentMode')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-center">{t('status')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentPayments.map(p => (
                      <tr key={p.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                        <td className="px-4 py-3 text-sm font-medium text-brand-700">{p.receiptNo}</td>
                        <td className="px-4 py-3 text-sm text-ink-900">{p.subscriberName}</td>
                        <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums font-medium">{formatINR(p.paidAmount)}</td>
                        <td className="px-4 py-3 text-sm text-ink-600 capitalize">{p.paymentMode.replace('_', ' ')}</td>
                        <td className="px-4 py-3 text-center"><StatusBadge status={p.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title={t('recentAuctionWinners')} action={<Button variant="ghost" onClick={() => onNavigate('auctions')}>{t('viewAll')} →</Button>} />
            <CardBody className="p-0">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-ink-200">
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-left">{t('subscriber')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-left">{t('chitGroup')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-center">{t('month')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-right">{t('discount')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide text-right">{t('prizeAmount')}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {completedAuctions.map(auc => (
                      <tr key={auc.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                        <td className="px-4 py-3 text-sm font-medium text-ink-900">{auc.winnerName}</td>
                        <td className="px-4 py-3 text-sm text-ink-600">{auc.chitGroupName}</td>
                        <td className="px-4 py-3 text-sm text-ink-600 text-center">M{auc.month}</td>
                        <td className="px-4 py-3 text-sm text-ink-700 text-right tabular-nums">{formatINR(auc.highestDiscount)}</td>
                        <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums font-medium">{auc.prizeAmount ? formatINR(auc.prizeAmount) : '—'}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}

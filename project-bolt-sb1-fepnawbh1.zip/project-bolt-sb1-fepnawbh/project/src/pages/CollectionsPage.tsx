import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { TopBar } from '@/components/Layout';
import { Card, StatusBadge, Button, EmptyState, InfoNote, CalculationRow, Modal } from '@/components/ui';
import { KPICard } from '@/components/Table';
import { formatINR, formatDate } from '@/utils/format';
import { subscribers, chitGroups, ledgerEntries } from '@/data/mockData';
import { calculatePenalty } from '@/utils/calculations';
import { HandCoins, Bell, Eye, Wallet, AlertCircle } from 'lucide-react';

export function CollectionsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [statusFilter, setStatusFilter] = useState('all');

  const collectionSubs = subscribers.filter(s => s.outstanding > 0 || s.status === 'overdue' || s.status === 'partial' || s.status === 'defaulted');
  const filtered = collectionSubs.filter(s => statusFilter === 'all' || s.status === statusFilter);

  const todayTarget = 500000;
  const todayCollected = 342000;
  const remaining = todayTarget - todayCollected;
  const overdueCount = collectionSubs.filter(s => s.status === 'overdue' || s.status === 'defaulted').length;

  return (
    <div>
      <TopBar title={t('collections')} subtitle={t('collections')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard label={t('todaysTarget')} value={formatINR(todayTarget, { compact: true })} icon={<Wallet size={18} />} />
          <KPICard label={t('todaysCollected')} value={formatINR(todayCollected, { compact: true })} icon={<HandCoins size={18} />} />
          <KPICard label={t('remaining')} value={formatINR(remaining, { compact: true })} icon={<Wallet size={18} />} accent="gold" />
          <KPICard label={t('overdue')} value={String(overdueCount)} icon={<AlertCircle size={18} />} accent="gold" />
        </div>

        <div className="flex gap-2 flex-wrap">
          {['all', 'partial', 'overdue', 'defaulted'].map(s => (
            <button key={s} onClick={() => setStatusFilter(s)}
              className={`px-4 py-2 rounded-lg text-sm font-medium ${statusFilter === s ? 'bg-brand-700 text-white' : 'bg-white text-ink-600 border border-ink-200 hover:bg-ink-50'}`}>
              {s === 'all' ? t('all') : t(s as never)}
            </button>
          ))}
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: t('customer'), align: 'left' }, { label: t('chit'), align: 'left' },
                    { label: t('due'), align: 'right' }, { label: t('paid'), align: 'right' },
                    { label: t('outstandingCol'), align: 'right' }, { label: t('dueDate'), align: 'left' },
                    { label: t('daysOverdue'), align: 'center' }, { label: t('status'), align: 'center' },
                    { label: t('actions'), align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(s => {
                  const chit = chitGroups.find(c => c.id === s.chitGroupId);
                  const dueAmt = chit?.monthlyContribution || 0;
                  const paid = dueAmt - s.outstanding;
                  const daysOverdue = s.status === 'overdue' ? 8 : s.status === 'defaulted' ? 35 : 0;
                  return (
                    <tr key={s.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                      <td className="px-4 py-3 text-sm font-medium text-ink-900">{s.name}</td>
                      <td className="px-4 py-3 text-sm text-ink-600">{chit?.name}</td>
                      <td className="px-4 py-3 text-sm text-ink-700 text-right tabular-nums">{formatINR(dueAmt)}</td>
                      <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(paid)}</td>
                      <td className="px-4 py-3 text-sm text-red-600 text-right tabular-nums font-medium">{formatINR(s.outstanding)}</td>
                      <td className="px-4 py-3 text-sm text-ink-600">{formatDate(s.lastPaymentDate)}</td>
                      <td className="px-4 py-3 text-sm text-center">{daysOverdue > 0 ? <span className="text-red-600 font-medium">{daysOverdue}</span> : '—'}</td>
                      <td className="px-4 py-3 text-center"><StatusBadge status={s.status} /></td>
                      <td className="px-4 py-3">
                        <div className="flex items-center justify-center gap-1">
                          <button onClick={() => onNavigate('payments')} className="p-1.5 rounded-lg text-brand-700 hover:bg-brand-50" title={t('recordPayment')}><HandCoins size={15} /></button>
                          <button className="p-1.5 rounded-lg text-gold-700 hover:bg-gold-50" title={t('sendReminder')}><Bell size={15} /></button>
                          <button onClick={() => onNavigate('subscribers')} className="p-1.5 rounded-lg text-ink-600 hover:bg-ink-100" title={t('viewCustomer')}><Eye size={15} /></button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <EmptyState title="No collections pending" />}
        </Card>
      </div>
    </div>
  );
}

export function OutstandingPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [branchFilter, setBranchFilter] = useState('all');

  const overdueSubs = subscribers.filter(s => s.outstanding > 0);
  const filtered = overdueSubs.filter(s => branchFilter === 'all' || s.branch === branchFilter);

  const totalOutstanding = overdueSubs.reduce((sum, s) => sum + s.outstanding, 0);
  const overdueAccounts = overdueSubs.length;
  const critical = overdueSubs.filter(s => s.status === 'defaulted').length;

  const aging = [
    { label: t('current'), amount: 1200000, color: 'bg-brand-500', pct: 55 },
    { label: t('days1to7'), amount: 380000, color: 'bg-gold-400', pct: 17 },
    { label: t('days8to30'), amount: 420000, color: 'bg-gold-600', pct: 19 },
    { label: t('days31Plus'), amount: 180000, color: 'bg-red-500', pct: 9 },
  ];

  return (
    <div>
      <TopBar title={t('outstanding')} subtitle={t('outstanding')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <KPICard label={t('totalOutstanding')} value={formatINR(2180000, { compact: true })} icon={<AlertCircle size={18} />} accent="gold" />
          <KPICard label={t('overdueAccounts')} value={String(overdueAccounts)} icon={<AlertCircle size={18} />} />
          <KPICard label={t('critical')} value={String(critical)} icon={<AlertCircle size={18} />} accent="gold" />
        </div>

        <Card>
          <div className="px-5 pt-5 pb-3"><h3 className="section-title">{t('aging')}</h3></div>
          <div className="px-5 pb-5 space-y-3">
            {aging.map(a => (
              <div key={a.label}>
                <div className="flex items-center justify-between mb-1.5">
                  <span className="text-sm text-ink-600">{a.label}</span>
                  <span className="text-sm font-semibold text-ink-900 tabular-nums">{formatINR(a.amount, { compact: true })}</span>
                </div>
                <div className="w-full h-2 bg-ink-100 rounded-full overflow-hidden">
                  <div className={`h-full rounded-full ${a.color}`} style={{ width: `${a.pct}%` }} />
                </div>
              </div>
            ))}
          </div>
        </Card>

        <div className="flex gap-3 flex-wrap">
          <select className="input w-auto" value={branchFilter} onChange={e => setBranchFilter(e.target.value)}>
            <option value="all">{t('branch')}: {t('all')}</option>
            <option value="Chennai HQ">Chennai HQ</option>
            <option value="Coimbatore">Coimbatore</option>
            <option value="Madurai">Madurai</option>
          </select>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: t('subscriber'), align: 'left' }, { label: t('chit'), align: 'left' },
                    { label: t('outstandingCol'), align: 'right' }, { label: t('dueDate'), align: 'left' },
                    { label: t('daysOverdue'), align: 'center' }, { label: t('penalty'), align: 'right' },
                    { label: t('totalOutstanding'), align: 'right' }, { label: t('status'), align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(s => {
                  const chit = chitGroups.find(c => c.id === s.chitGroupId);
                  const daysOverdue = s.status === 'overdue' ? 8 : s.status === 'defaulted' ? 35 : 0;
                  const penalty = calculatePenalty(s.outstanding, daysOverdue, chit?.penaltyRate || 2);
                  const total = s.outstanding + penalty;
                  return (
                    <tr key={s.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                      <td className="px-4 py-3 text-sm font-medium text-ink-900">{s.name}</td>
                      <td className="px-4 py-3 text-sm text-ink-600">{chit?.name}</td>
                      <td className="px-4 py-3 text-sm text-red-600 text-right tabular-nums font-medium">{formatINR(s.outstanding)}</td>
                      <td className="px-4 py-3 text-sm text-ink-600">{formatDate(s.lastPaymentDate)}</td>
                      <td className="px-4 py-3 text-sm text-center">{daysOverdue > 0 ? <span className="text-red-600">{daysOverdue}</span> : '—'}</td>
                      <td className="px-4 py-3 text-sm text-ink-700 text-right tabular-nums">{penalty > 0 ? formatINR(penalty) : '—'}</td>
                      <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums font-bold">{formatINR(total)}</td>
                      <td className="px-4 py-3 text-center"><StatusBadge status={s.status} /></td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <EmptyState title="No overdue payments" />}
        </Card>

        <Card>
          <div className="px-5 pt-5 pb-3"><h3 className="section-title">{t('penalty') + ' - ' + t('howCalculated')}</h3></div>
          <div className="px-5 pb-5">
            <CalculationRow label={t('dueAmount')} value={formatINR(50000)} />
            <CalculationRow label={t('paid')} value={formatINR(40000)} />
            <CalculationRow label={t('outstandingCol')} value={formatINR(10000)} />
            <CalculationRow label={t('daysOverdue')} value="12" />
            <CalculationRow label={t('penalty')} value={formatINR(calculatePenalty(10000, 12, 2))} bold />
            <InfoNote variant="warning">{t('penaltyNote')}</InfoNote>
          </div>
        </Card>
      </div>
    </div>
  );
}

export function LedgerPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [typeFilter, setTypeFilter] = useState('all');
  const [showReverse, setShowReverse] = useState(false);
  const [reverseReason, setReverseReason] = useState('');

  const filtered = ledgerEntries.filter(e => typeFilter === 'all' || e.type === typeFilter);
  const totalDebit = ledgerEntries.reduce((s, e) => s + e.debit, 0);
  const totalCredit = ledgerEntries.reduce((s, e) => s + e.credit, 0);
  const netBalance = totalCredit - totalDebit;

  return (
    <div>
      <TopBar title={t('ledger')} subtitle={t('ledger')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <KPICard label={t('debit')} value={formatINR(totalDebit, { compact: true })} icon={<Wallet size={18} />} accent="gold" />
          <KPICard label={t('credit')} value={formatINR(totalCredit, { compact: true })} icon={<Wallet size={18} />} />
          <KPICard label={t('balance')} value={formatINR(netBalance, { compact: true })} icon={<Wallet size={18} />} />
        </div>

        <div className="flex gap-3 flex-wrap">
          <select className="input w-auto" value={typeFilter} onChange={e => setTypeFilter(e.target.value)}>
            <option value="all">{t('transactionType')}: {t('all')}</option>
            <option value="subscription">{t('subscription')}</option>
            <option value="dividend">{t('dividend')}</option>
            <option value="prize_payment">{t('prizePayment')}</option>
            <option value="commission">{t('commission')}</option>
            <option value="penalty">{t('penalty')}</option>
            <option value="adjustment">{t('adjustment')}</option>
            <option value="reversal">{t('reversal')}</option>
            <option value="refund">{t('refund')}</option>
          </select>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: t('date'), align: 'left' }, { label: t('transactionId'), align: 'left' },
                    { label: t('account'), align: 'left' }, { label: t('description'), align: 'left' },
                    { label: t('debit'), align: 'right' }, { label: t('credit'), align: 'right' },
                    { label: t('balance'), align: 'right' }, { label: t('reference'), align: 'left' },
                    { label: t('createdBy'), align: 'left' }, { label: t('actions'), align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(e => (
                  <tr key={e.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm text-ink-600 whitespace-nowrap">{formatDate(e.date)}</td>
                    <td className="px-4 py-3 text-sm font-medium text-brand-700">{e.transactionId}</td>
                    <td className="px-4 py-3 text-sm text-ink-900">{e.account}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{e.description}</td>
                    <td className="px-4 py-3 text-sm text-right tabular-nums">{e.debit > 0 ? <span className="text-red-600 font-medium">{formatINR(e.debit)}</span> : '—'}</td>
                    <td className="px-4 py-3 text-sm text-right tabular-nums">{e.credit > 0 ? <span className="text-brand-600 font-medium">{formatINR(e.credit)}</span> : '—'}</td>
                    <td className="px-4 py-3 text-sm text-ink-700 text-right tabular-nums">{formatINR(Math.abs(e.balance))}</td>
                    <td className="px-4 py-3 text-sm text-ink-500">{e.reference}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{e.createdBy}</td>
                    <td className="px-4 py-3 text-center">
                      <button onClick={() => setShowReverse(true)} className="text-xs text-gold-700 hover:text-gold-800 font-medium">{t('reversal')}</button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <EmptyState title="No ledger entries found" />}
        </Card>
      </div>

      {/* Reversal Modal */}
      <Modal open={showReverse} onClose={() => setShowReverse(false)} title={t('reversal')} size="sm">
        <div className="space-y-4">
          <p className="text-sm text-ink-600">Reversal requires a mandatory reason. This action will be logged in the audit trail.</p>
          <div>
            <label className="label">{t('reason')} <span className="text-red-500">*</span></label>
            <textarea className="input min-h-[80px]" value={reverseReason} onChange={e => setReverseReason(e.target.value)} placeholder="Enter reason for reversal..." />
          </div>
          <InfoNote variant="warning">Financial transactions cannot be hard-deleted. Reversal creates an offsetting entry with full audit trail.</InfoNote>
          <div className="flex justify-end gap-2"><Button variant="secondary" onClick={() => setShowReverse(false)}>{t('cancel')}</Button><Button disabled={!reverseReason} onClick={() => { setShowReverse(false); setReverseReason(''); }}>{t('confirm')} {t('reversal')}</Button></div>
        </div>
      </Modal>
    </div>
  );
}

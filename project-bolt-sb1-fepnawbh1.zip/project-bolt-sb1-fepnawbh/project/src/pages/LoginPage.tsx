import { useApp } from '@/context/AppContext';
import { ShieldCheck, Building2, Calculator, HandCoins, Gavel, User, ArrowRight } from 'lucide-react';
import type { UserRole } from '@/types';
import type { TranslationKey } from '@/i18n/translations';
import { cn } from '@/utils/cn';

const roles: { role: UserRole; labelKey: TranslationKey; icon: typeof ShieldCheck; desc: string }[] = [
  { role: 'super_admin', labelKey: 'superAdmin', icon: ShieldCheck, desc: 'Full access to all modules, branches, staff and settings' },
  { role: 'branch_manager', labelKey: 'branchManager', icon: Building2, desc: 'Branch-level dashboard, subscribers, collections, auctions and approvals' },
  { role: 'accountant', labelKey: 'accountant', icon: Calculator, desc: 'Payments, receipts, ledger, reconciliation and financial reports' },
  { role: 'collection_staff', labelKey: 'collectionStaff', icon: HandCoins, desc: 'Assigned subscribers, payment collection and outstanding tracking' },
  { role: 'auction_staff', labelKey: 'auctionStaff', icon: Gavel, desc: 'Auction management, eligible members, bids and auction results' },
  { role: 'customer', labelKey: 'customerSubscriber', icon: User, desc: 'View your chit, payments, receipts, auction status and statements' },
];

export function LoginPage() {
  const { t, setRole, language, setLanguage } = useApp();

  return (
    <div className="min-h-screen flex flex-col lg:flex-row bg-ink-50">
      {/* Left panel */}
      <div className="lg:w-1/2 bg-brand-800 text-white p-8 lg:p-12 flex flex-col justify-between relative overflow-hidden">
        <div className="absolute top-0 right-0 w-96 h-96 bg-brand-700 rounded-full -translate-y-1/3 translate-x-1/3 opacity-30"></div>
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-gold-600 rounded-full translate-y-1/2 -translate-x-1/4 opacity-10"></div>

        <div className="relative z-10">
          <div className="flex items-center gap-3 mb-12">
            <div className="w-12 h-12 rounded-lg bg-white/10 backdrop-blur flex items-center justify-center">
              <span className="text-gold-200 font-bold text-xl font-display">L</span>
            </div>
            <div>
              <p className="font-display font-bold text-lg leading-tight">{t('brandName')}</p>
              <p className="text-sm text-brand-200">{t('brandSubtitle')}</p>
            </div>
          </div>

          <div className="max-w-md">
            <h2 className="text-2xl lg:text-3xl font-bold mb-4 font-display leading-tight">
              A complete digital operating system for chit fund businesses.
            </h2>
            <p className="text-brand-100 text-base mb-8">
              Manage chits, subscribers, auctions, collections, dividends, prize payments and financial records from one platform.
            </p>

            <div className="grid grid-cols-3 gap-4">
              <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                <p className="text-gold-200 text-xs font-semibold uppercase tracking-wide mb-2">{t('operations')}</p>
                <ul className="text-sm text-brand-100 space-y-1">
                  <li>{t('chitGroups')}</li>
                  <li>{t('auctions')}</li>
                  <li>{t('collections')}</li>
                </ul>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                <p className="text-gold-200 text-xs font-semibold uppercase tracking-wide mb-2">{t('finance')}</p>
                <ul className="text-sm text-brand-100 space-y-1">
                  <li>{t('payments')}</li>
                  <li>{t('dividends')}</li>
                  <li>{t('prizePayments')}</li>
                  <li>{t('ledger')}</li>
                </ul>
              </div>
              <div className="bg-white/10 backdrop-blur rounded-xl p-4">
                <p className="text-gold-200 text-xs font-semibold uppercase tracking-wide mb-2">{t('customer')}</p>
                <ul className="text-sm text-brand-100 space-y-1">
                  <li>{t('myChit')}</li>
                  <li>{t('payments')}</li>
                  <li>{t('viewReceipts')}</li>
                </ul>
              </div>
            </div>
          </div>
        </div>

        <div className="relative z-10 text-sm text-brand-200 mt-8">
          <p>Trusted by families across Tamil Nadu for decades</p>
        </div>
      </div>

      {/* Right panel */}
      <div className="lg:w-1/2 flex items-center justify-center p-6 lg:p-12">
        <div className="w-full max-w-md">
          <div className="flex items-center justify-end mb-6">
            <div className="flex items-center rounded-lg border border-ink-200 overflow-hidden">
              <button onClick={() => setLanguage('en')} className={cn('px-3 py-1.5 text-sm font-medium', language === 'en' ? 'bg-brand-700 text-white' : 'text-ink-600 hover:bg-ink-100')}>English</button>
              <button onClick={() => setLanguage('ta')} className={cn('px-3 py-1.5 text-sm font-medium', language === 'ta' ? 'bg-brand-700 text-white' : 'text-ink-600 hover:bg-ink-100')}>தமிழ்</button>
            </div>
          </div>

          <h1 className="text-2xl font-bold text-ink-900 mb-1 font-display">{t('loginTitle')}</h1>
          <p className="text-sm text-ink-500 mb-6">{t('loginSubtitle')}</p>

          <div className="flex items-center gap-2 mb-4">
            <span className="text-xs font-semibold text-gold-700 bg-gold-100 px-2.5 py-1 rounded-full">{t('demoMode')}</span>
          </div>

          <div className="space-y-3">
            {roles.map(({ role, labelKey, icon: Icon, desc }) => (
              <button
                key={role}
                onClick={() => setRole(role)}
                className="w-full card p-4 flex items-center gap-4 text-left transition-all hover:shadow-card-hover hover:border-brand-300 group"
              >
                <div className="w-11 h-11 rounded-lg bg-brand-50 text-brand-700 flex items-center justify-center flex-shrink-0 group-hover:bg-brand-100 transition-colors">
                  <Icon size={20} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="font-semibold text-ink-900 text-sm">{t(labelKey)}</p>
                  <p className="text-xs text-ink-500 truncate">{desc}</p>
                </div>
                <ArrowRight size={18} className="text-ink-300 group-hover:text-brand-600 flex-shrink-0 transition-colors" />
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { TopBar } from '@/components/Layout';
import { Card, CardHeader, CardBody, StatusBadge, Button, EmptyState, InfoNote, CalculationRow, HowCalculated } from '@/components/ui';
import { KPICard } from '@/components/Table';
import { formatINR, formatDate } from '@/utils/format';
import { dividends, prizeRecords, chitGroups, staffUsers, documents, notifications, auditEntries } from '@/data/mockData';
import { calculateFullScenario, type FullCalcResult } from '@/utils/calculations';
import { Coins, Trophy, Check, X, FileText, ScrollText, Building2, ShieldCheck, Bell, FileText as FileTextIcon, Settings as SettingsIcon, Calculator, AlertCircle } from 'lucide-react';

export function DividendsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const totalDistributed = dividends.filter(d => d.status === 'distributed').reduce((s, d) => s + d.totalDistributed, 0);
  const totalPending = dividends.filter(d => d.status === 'pending').reduce((s, d) => s + d.dividendPool, 0);

  return (
    <div>
      <TopBar title={t('dividends')} subtitle={t('dividends')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard label={t('totalDividendDistributed')} value={formatINR(totalDistributed, { compact: true })} icon={<Coins size={18} />} />
          <KPICard label={t('pending')} value={formatINR(totalPending, { compact: true })} icon={<Coins size={18} />} accent="gold" />
          <KPICard label={t('distributed')} value={String(dividends.filter(d => d.status === 'distributed').length)} icon={<Check size={18} />} />
          <KPICard label={t('pending')} value={String(dividends.filter(d => d.status === 'pending').length)} icon={<AlertCircle size={18} />} accent="gold" />
        </div>

        <Card>
          <CardHeader title={t('dividends')} />
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: 'ID', align: 'left' }, { label: t('chitGroup'), align: 'left' },
                    { label: t('month'), align: 'center' }, { label: t('dividendPool'), align: 'right' },
                    { label: t('subscribersCount'), align: 'center' }, { label: t('dividendPerSubscriber'), align: 'right' },
                    { label: t('totalDividendDistributed'), align: 'right' }, { label: t('date'), align: 'left' },
                    { label: t('status'), align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {dividends.map(d => (
                  <tr key={d.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm font-medium text-brand-700">{d.id}</td>
                    <td className="px-4 py-3 text-sm text-ink-900">{d.chitGroupName}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">M{d.month}</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(d.dividendPool)}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">{d.subscribers}</td>
                    <td className="px-4 py-3 text-sm text-brand-700 text-right tabular-nums font-medium">{formatINR(d.dividendPerMember)}</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(d.totalDistributed)}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{formatDate(d.date)}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={d.status} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {dividends.length === 0 && <EmptyState title="No dividends found" />}
        </Card>

        <Card>
          <CardHeader title={t('howCalculated')} />
          <CardBody>
            <CalculationRow label={t('auctionDiscount')} value={formatINR(200000)} />
            <CalculationRow label={t('foremanCommission')} value={formatINR(50000)} />
            <CalculationRow label={t('potentialDistributableAmount')} value={formatINR(150000)} bold />
            <CalculationRow label={t('subscribersCount')} value="20" />
            <CalculationRow label={t('illustrativeDividend')} value={formatINR(7500)} bold />
            <InfoNote>{t('dividendNote')}</InfoNote>
          </CardBody>
        </Card>
      </div>
    </div>
  );
}

export function PrizePaymentsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  return (
    <div>
      <TopBar title={t('prizePayments')} subtitle={t('prizePayments')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard label={t('approved')} value={String(prizeRecords.filter(p => p.status === 'approved').length)} icon={<Check size={18} />} />
          <KPICard label={t('underReview')} value={String(prizeRecords.filter(p => p.status === 'under_review').length)} icon={<AlertCircle size={18} />} accent="gold" />
          <KPICard label={t('prizeAmount')} value={formatINR(prizeRecords.reduce((s, p) => s + p.prizeAmount, 0), { compact: true })} icon={<Trophy size={18} />} />
          <KPICard label={t('futureLiability')} value={formatINR(prizeRecords.reduce((s, p) => s + p.futureLiability, 0), { compact: true })} icon={<AlertCircle size={18} />} accent="gold" />
        </div>

        {prizeRecords.map(prize => (
          <Card key={prize.id}>
            <CardHeader title={`${prize.subscriberName} - ${prize.chitGroupName}`} action={<StatusBadge status={prize.status} />} />
            <CardBody>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm mb-4">
                <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('chitValue')}</p><p className="font-bold text-ink-900">{formatINR(prize.chitValue)}</p></div>
                <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('discount')}</p><p className="font-bold text-ink-900">{formatINR(prize.discount)}</p></div>
                <div className="bg-brand-50 rounded-lg p-3"><p className="text-xs text-brand-700">{t('prizeAmount')}</p><p className="font-bold text-brand-800">{formatINR(prize.prizeAmount)}</p></div>
                <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('commission')}</p><p className="font-bold text-ink-900">{formatINR(prize.commission)}</p></div>
                <div className="bg-gold-50 rounded-lg p-3"><p className="text-xs text-gold-700">{t('dividendPool')}</p><p className="font-bold text-gold-800">{formatINR(prize.dividendPool)}</p></div>
                <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('auctionMonth')}</p><p className="font-bold text-ink-900">M{prize.auctionMonth}</p></div>
                <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('remainingMonths')}</p><p className="font-bold text-ink-900">{prize.remainingMonths}</p></div>
                <div className="bg-red-50 rounded-lg p-3"><p className="text-xs text-red-600">{t('futureLiability')}</p><p className="font-bold text-red-700">{formatINR(prize.futureLiability)}</p></div>
              </div>
              {prize.status === 'under_review' ? (
                <div className="flex gap-2 flex-wrap">
                  <Button variant="secondary">{t('review')}</Button>
                  <Button variant="primary"><Check size={16} /> {t('approve')}</Button>
                  <Button variant="danger"><X size={16} /> {t('reject')}</Button>
                  <Button variant="ghost"><FileText size={16} /> {t('generatePrizeStatement')}</Button>
                </div>
              ) : prize.approvedBy ? (
                <p className="text-sm text-ink-500">{t('approvedBy')}: <span className="font-medium text-ink-900">{prize.approvedBy}</span> · {prize.approvedAt ? formatDate(prize.approvedAt) : ''}</p>
              ) : null}
            </CardBody>
          </Card>
        ))}
      </div>
    </div>
  );
}

export function ReconciliationPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const expected = 500000;
  const actual = 485000;
  const diff = expected - actual;
  return (
    <div>
      <TopBar title={t('reconciliation')} subtitle={t('reconciliation')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
          <KPICard label={t('expectedCollectionAmount')} value={formatINR(expected, { compact: true })} icon={<ScrollText size={18} />} />
          <KPICard label={t('actualCollectionAmount')} value={formatINR(actual, { compact: true })} icon={<ScrollText size={18} />} />
          <KPICard label={t('difference')} value={formatINR(diff, { compact: true })} icon={<AlertCircle size={18} />} accent="gold" />
          <KPICard label={t('status')} value={t('needsReview')} icon={<AlertCircle size={18} />} accent="gold" />
        </div>

        <Card>
          <CardHeader title={t('reconciliation')} />
          <CardBody>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mb-4">
              {[
                { label: t('cash'), expected: 200000, actual: 195000 },
                { label: t('upi'), expected: 150000, actual: 150000 },
                { label: t('bankTransfer'), expected: 100000, actual: 95000 },
                { label: t('cheque'), expected: 50000, actual: 45000 },
              ].map(r => (
                <div key={r.label} className="border border-ink-200 rounded-lg p-3">
                  <p className="text-sm font-medium text-ink-900 mb-2">{r.label}</p>
                  <div className="flex justify-between text-xs"><span className="text-ink-500">{t('expectedCollectionAmount')}</span><span className="tabular-nums">{formatINR(r.expected)}</span></div>
                  <div className="flex justify-between text-xs"><span className="text-ink-500">{t('actualCollectionAmount')}</span><span className="tabular-nums">{formatINR(r.actual)}</span></div>
                  <div className="flex justify-between text-xs mt-1 pt-1 border-t border-ink-100"><span className="text-ink-500">{t('difference')}</span><span className={`tabular-nums font-medium ${r.expected - r.actual !== 0 ? 'text-red-600' : 'text-brand-600'}`}>{formatINR(r.expected - r.actual)}</span></div>
                </div>
              ))}
            </div>
          </CardBody>
        </Card>

        <Card>
          <CardHeader title="Unmatched Transactions" />
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr className="border-b border-ink-200">
                <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-left">{t('transactionId')}</th>
                <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-left">{t('description')}</th>
                <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-right">{t('amount')}</th>
                <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-center">{t('status')}</th>
              </tr></thead>
              <tbody>
                {[
                  { id: 'TXN-U001', desc: 'Cash - unverified deposit', amount: 5000 },
                  { id: 'TXN-U002', desc: 'Cheque #456789 - pending clearance', amount: 50000 },
                ].map(u => (
                  <tr key={u.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm font-medium text-brand-700">{u.id}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{u.desc}</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(u.amount)}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status="unmatched" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

export function ReportsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const reportCategories = [
    { title: t('chitReports'), icon: FileTextIcon, reports: [t('activeChits'), t('completedChits'), t('chitWiseCollection')] },
    { title: t('subscriberReports'), icon: ShieldCheck, reports: [t('subscriberList'), t('prizedSubscribersReport'), t('nonPrizedSubscribers'), t('defaultedSubscribers')] },
    { title: t('auctionReports'), icon: Trophy, reports: [t('auctionHistory'), t('bidHistory'), t('winnerReport'), t('discountReport')] },
    { title: t('financialReports'), icon: Coins, reports: [t('collectionReport'), t('dividendReport'), t('prizePaymentReport'), t('outstandingReport'), t('commissionReport'), t('ledgerReport'), t('reconciliationReport'), t('profitLossReport')] },
    { title: t('branchReports'), icon: Building2, reports: ['Branch Performance', 'Branch Collection', 'Branch Outstanding'] },
  ];

  return (
    <div>
      <TopBar title={t('reports')} subtitle={t('reports')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="flex gap-3 flex-wrap items-end">
          <div><label className="label">{t('dateRange')}</label><input type="date" className="input" /></div>
          <div><label className="label">To</label><input type="date" className="input" /></div>
          <select className="input w-auto"><option>All Branches</option><option>Chennai HQ</option><option>Coimbatore</option><option>Madurai</option></select>
          <select className="input w-auto"><option>All Chits</option>{chitGroups.map(c => <option key={c.id}>{c.name}</option>)}</select>
          <Button variant="secondary">{t('export')}</Button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {reportCategories.map(cat => {
            const Icon = cat.icon;
            return (
              <Card key={cat.title}>
                <CardHeader title={cat.title} />
                <CardBody>
                  <div className="space-y-1">
                    {cat.reports.map(r => (
                      <button key={r} className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm text-ink-700 hover:bg-ink-50 hover:text-brand-700 transition-colors text-left">
                        <Icon size={16} className="text-ink-400 flex-shrink-0" />
                        <span className="flex-1">{r}</span>
                        <span className="text-ink-300">→</span>
                      </button>
                    ))}
                  </div>
                </CardBody>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

export function CalculatorPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [input, setInput] = useState({
    chitValue: '1000000', members: '20', duration: '20', auctionMonth: '5',
    auctionDiscount: '200000', commission: '5',
  });
  const [result, setResult] = useState<FullCalcResult | null>(null);

  const handleCalculate = () => {
    setResult(calculateFullScenario({
      chitValue: Number(input.chitValue), members: Number(input.members), duration: Number(input.duration),
      commissionPercent: Number(input.commission), auctionMonth: Number(input.auctionMonth),
      auctionDiscount: Number(input.auctionDiscount), dividendRule: 'equal',
    }));
  };

  return (
    <div>
      <TopBar title={t('chitCalculator')} subtitle={t('chitCalculator')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          <Card>
            <CardHeader title={t('chitCalculator')} />
            <CardBody>
              <div className="grid grid-cols-2 gap-4">
                <div><label className="label">{t('chitValue')}</label><input className="input" type="number" value={input.chitValue} onChange={e => setInput({...input, chitValue: e.target.value})} /></div>
                <div><label className="label">{t('numberOfMembers')}</label><input className="input" type="number" value={input.members} onChange={e => setInput({...input, members: e.target.value})} /></div>
                <div><label className="label">{t('duration')}</label><input className="input" type="number" value={input.duration} onChange={e => setInput({...input, duration: e.target.value})} /></div>
                <div><label className="label">{t('monthlyContribution')}</label><input className="input bg-ink-50" disabled value={Number(input.chitValue) / Number(input.members) || 0} /></div>
                <div><label className="label">{t('auctionMonth')}</label><input className="input" type="number" value={input.auctionMonth} onChange={e => setInput({...input, auctionMonth: e.target.value})} /></div>
                <div><label className="label">{t('auctionDiscount')}</label><input className="input" type="number" value={input.auctionDiscount} onChange={e => setInput({...input, auctionDiscount: e.target.value})} /></div>
                <div><label className="label">{t('commission')} %</label><input className="input" type="number" value={input.commission} onChange={e => setInput({...input, commission: e.target.value})} /></div>
              </div>
              <div className="flex gap-2 mt-4"><Button onClick={handleCalculate}><Calculator size={16} /> {t('calculate')}</Button><Button variant="secondary">{t('reset')}</Button><Button variant="gold">{t('saveScenario')}</Button></div>
            </CardBody>
          </Card>

          <Card>
            <CardHeader title={t('results')} />
            <CardBody>
              {result ? (
                <div className="space-y-1">
                  <CalculationRow label={t('chitValue')} value={formatINR(result.chitValue)} />
                  <CalculationRow label={t('monthlyContribution')} value={formatINR(result.monthlyContribution)} />
                  <CalculationRow label={t('auctionDiscount')} value={formatINR(result.auctionDiscount)} />
                  <CalculationRow label={t('discountPercent')} value={`${result.discountPercent.toFixed(1)}%`} />
                  <CalculationRow label={t('prizeAmount')} value={formatINR(result.prizeAmount)} bold />
                  <CalculationRow label={t('commission')} value={formatINR(result.commission)} />
                  <CalculationRow label={t('dividendPool')} value={formatINR(result.dividendPool)} />
                  <CalculationRow label={t('illustrativeDividend')} value={formatINR(result.dividendPerMember)} />
                  <CalculationRow label={t('remainingMonths')} value={String(result.remainingMonths)} />
                  <CalculationRow label={t('futureSubscriptionLiability')} value={formatINR(result.futureLiability)} bold />
                  <CalculationRow label={t('totalPaidCalc')} value={formatINR(result.totalPaid)} />
                  <CalculationRow label={t('totalReceived')} value={formatINR(result.totalReceived)} />
                  <CalculationRow label={t('netCashFlow')} value={formatINR(result.netCashFlow)} bold />
                  <InfoNote>{t('illustrativeReturn')}</InfoNote>
                </div>
              ) : <EmptyState title={t('calculate')} subtitle="Enter values and click Calculate" />}
            </CardBody>
          </Card>
        </div>
      </div>
    </div>
  );
}

export function BranchesPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  return (
    <div>
      <TopBar title={t('branches')} subtitle={t('branches')} />
      <div className="p-4 lg:p-6 space-y-4">
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr className="border-b border-ink-200">
                {[
                  { label: t('branch'), align: 'left' }, { label: t('manager'), align: 'left' },
                  { label: t('activeChits'), align: 'center' }, { label: t('subscribers'), align: 'center' },
                  { label: t('monthlyCollectionBranch'), align: 'right' }, { label: t('outstanding'), align: 'right' },
                  { label: t('status'), align: 'center' },
                ].map((h, i) => (
                  <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                ))}
              </tr></thead>
              <tbody>
                {[{ name: 'Chennai HQ', manager: 'S. Venkatesan', activeChits: 62, subscribers: 1840, monthlyCollection: 8420000, outstanding: 980000 },
                  { name: 'Coimbatore', manager: 'R. Murugan', activeChits: 48, subscribers: 1240, monthlyCollection: 6210000, outstanding: 720000 },
                  { name: 'Madurai', manager: 'K. Rajendran', activeChits: 32, subscribers: 760, monthlyCollection: 3820000, outstanding: 480000 },
                ].map(b => (
                  <tr key={b.name} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm font-medium text-ink-900">{b.name}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{b.manager}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">{b.activeChits}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">{b.subscribers}</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(b.monthlyCollection)}</td>
                    <td className="px-4 py-3 text-sm text-right tabular-nums">{formatINR(b.outstanding)}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status="active" /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

export function StaffPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();

  return (
    <div>
      <TopBar title={t('staffRoles')} subtitle={t('staffRoles')} />
      <div className="p-4 lg:p-6 space-y-4">
        <Card>
          <CardHeader title={t('staffList')} />
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr className="border-b border-ink-200">
                {[
                  { label: t('name'), align: 'left' }, { label: t('role'), align: 'left' },
                  { label: t('branch'), align: 'left' }, { label: t('status'), align: 'center' },
                  { label: t('lastLogin'), align: 'left' },
                ].map((h, i) => (
                  <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                ))}
              </tr></thead>
              <tbody>
                {staffUsers.map((s: any) => (
                  <tr key={s.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm font-medium text-ink-900">{s.name}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 capitalize">{s.role.replace('_', ' ')}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{s.branch}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={s.status} /></td>
                    <td className="px-4 py-3 text-sm text-ink-600">{formatDate(s.lastLogin)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        <Card>
          <CardHeader title={t('permissionsMatrix')} />
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr className="border-b border-ink-200">
                <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-left">{t('role')}</th>
                {['View', 'Create', 'Edit', 'Approve', 'Export'].map(p => <th key={p} className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-center">{p}</th>)}
              </tr></thead>
              <tbody>
                {staffUsers.map((s: any) => (
                  <tr key={s.id} className="border-b border-ink-100 last:border-0">
                    <td className="px-4 py-3 text-sm font-medium text-ink-900 capitalize">{s.role.replace('_', ' ')}</td>
                    {[s.permissions.view, s.permissions.create, s.permissions.edit, s.permissions.approve, s.permissions.export].map((p, i) => (
                      <td key={i} className="px-4 py-3 text-center">{p ? <Check size={16} className="text-brand-600 mx-auto" /> : <X size={16} className="text-ink-300 mx-auto" />}</td>
                    ))}
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

export function DocumentsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();

  return (
    <div>
      <TopBar title={t('documents')} subtitle={t('documents')} />
      <div className="p-4 lg:p-6 space-y-4">
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr className="border-b border-ink-200">
                {[
                  { label: t('subscriber'), align: 'left' }, { label: t('documents'), align: 'left' },
                  { label: t('status'), align: 'center' }, { label: t('date'), align: 'left' },
                ].map((h, i) => (
                  <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                ))}
              </tr></thead>
              <tbody>
                {documents.map((d: any) => (
                  <tr key={d.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm font-medium text-ink-900">{d.subscriberName}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{d.name}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={d.status} /></td>
                    <td className="px-4 py-3 text-sm text-ink-600">{formatDate(d.uploadedDate)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

export function NotificationsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t, language } = useApp();

  return (
    <div>
      <TopBar title={t('notifications')} subtitle={t('notifications')} />
      <div className="p-4 lg:p-6 space-y-4">
        <Card>
          <div className="divide-y divide-ink-100">
            {notifications.map((n: any) => (
              <div key={n.id} className={`flex items-start gap-3 p-4 ${!n.read ? 'bg-brand-50/50' : ''}`}>
                <div className={`w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0 ${
                  n.type === 'overdue' ? 'bg-red-100 text-red-600' : n.type === 'payment_received' || n.type === 'dividend_credited' || n.type === 'prize_approved' ? 'bg-brand-100 text-brand-600' : 'bg-gold-100 text-gold-700'
                }`}>
                  <Bell size={18} />
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-ink-900">{language === 'ta' ? n.titleTa : n.title}</p>
                  <p className="text-sm text-ink-600">{language === 'ta' ? n.messageTa : n.message}</p>
                  <p className="text-xs text-ink-400 mt-1">{formatDate(n.date)}</p>
                </div>
                {!n.read && <div className="w-2 h-2 rounded-full bg-brand-600 flex-shrink-0 mt-2"></div>}
              </div>
            ))}
          </div>
        </Card>
      </div>
    </div>
  );
}

export function AuditTrailPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();

  return (
    <div>
      <TopBar title={t('auditTrail')} subtitle={t('auditTrail')} />
      <div className="p-4 lg:p-6 space-y-4">
        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead><tr className="border-b border-ink-200">
                {[
                  { label: t('user'), align: 'left' }, { label: t('role'), align: 'left' },
                  { label: t('action'), align: 'left' }, { label: t('record'), align: 'left' },
                  { label: t('oldValue'), align: 'left' }, { label: t('newValue'), align: 'left' },
                  { label: t('timestamp'), align: 'left' }, { label: t('reason'), align: 'left' },
                  { label: t('ipAddress'), align: 'left' }, { label: t('approvalStatus'), align: 'center' },
                ].map((h, i) => (
                  <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                ))}
              </tr></thead>
              <tbody>
                {auditEntries.map((a: any) => (
                  <tr key={a.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm font-medium text-ink-900">{a.user}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{a.role}</td>
                    <td className="px-4 py-3 text-sm text-ink-700">{a.action}</td>
                    <td className="px-4 py-3 text-sm text-brand-700">{a.record}</td>
                    <td className="px-4 py-3 text-sm text-red-600">{a.oldValue || '—'}</td>
                    <td className="px-4 py-3 text-sm text-brand-600">{a.newValue || '—'}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 whitespace-nowrap">{formatDate(a.timestamp)}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{a.reason}</td>
                    <td className="px-4 py-3 text-sm text-ink-500 whitespace-nowrap">{a.ipAddress}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={a.approvalStatus} /></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>
      </div>
    </div>
  );
}

export function SettingsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const sections = [
    { title: t('company'), icon: Building2, fields: [t('companyName'), t('logo'), t('address'), t('contact')] },
    { title: t('chitRules'), icon: ShieldCheck, fields: [t('commission'), t('auctionRules'), t('dividendRules'), t('paymentRules')] },
    { title: t('notifications'), icon: Bell, fields: [t('sms'), t('emailLabel'), t('whatsapp')] },
    { title: t('security'), icon: ShieldCheck, fields: [t('sessionTimeout'), t('passwordPolicy'), t('twoFA')] },
    { title: t('audit'), icon: ScrollText, fields: [t('retention'), t('sensitiveActions')] },
  ];
  return (
    <div>
      <TopBar title={t('settings')} subtitle={t('settings')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {sections.map(s => {
            const Icon = s.icon;
            return (
              <Card key={s.title}>
                <CardHeader title={s.title} />
                <CardBody>
                  <div className="space-y-3">
                    {s.fields.map(f => (
                      <div key={f}>
                        <label className="label">{f}</label>
                        <input className="input" placeholder={f} />
                      </div>
                    ))}
                  </div>
                </CardBody>
              </Card>
            );
          })}
        </div>
      </div>
    </div>
  );
}

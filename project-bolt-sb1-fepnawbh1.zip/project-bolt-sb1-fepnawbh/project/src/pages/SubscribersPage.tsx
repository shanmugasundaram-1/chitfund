import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { TopBar } from '@/components/Layout';
import { Card, StatusBadge, Button, Modal, EmptyState } from '@/components/ui';
import { formatINR, formatDate, maskPan, maskAadhaar } from '@/utils/format';
import { subscribers, chitGroups, payments, documents, auditEntries, auctions } from '@/data/mockData';
import { Search, Eye, Phone, Mail, MapPin, User, FileText, Wallet, Trophy, Coins, Calendar } from 'lucide-react';
import type { Subscriber } from '@/types';

export function SubscribersPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [search, setSearch] = useState('');
  const [statusFilter, setStatusFilter] = useState('all');
  const [branchFilter, setBranchFilter] = useState('all');
  const [prizeFilter, setPrizeFilter] = useState('all');
  const [selected, setSelected] = useState<Subscriber | null>(null);

  const filtered = subscribers.filter(s => {
    const matchSearch = s.name.toLowerCase().includes(search.toLowerCase()) || s.phone.includes(search) || s.id.toLowerCase().includes(search.toLowerCase());
    const matchStatus = statusFilter === 'all' || s.status === statusFilter;
    const matchBranch = branchFilter === 'all' || s.branch === branchFilter;
    const matchPrize = prizeFilter === 'all' || s.prizeStatus === prizeFilter;
    return matchSearch && matchStatus && matchBranch && matchPrize;
  });

  const chitGroup = selected ? chitGroups.find(c => c.id === selected.chitGroupId) : null;
  const subPayments = selected ? payments.filter(p => p.subscriberId === selected.id) : [];
  const subDocs = selected ? documents.filter(d => d.subscriberId === selected.id) : [];
  const subAuctions = selected ? auctions.filter(a => a.winnerId === selected.id) : [];
  const subAudit = selected ? auditEntries.filter(a => a.record.includes(selected.id) || a.record.includes(selected.receiptNo || '')) : [];

  return (
    <div>
      <TopBar title={t('subscribers')} subtitle={`${subscribers.length} ${t('subscribers').toLowerCase()}`} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="flex flex-col sm:flex-row gap-3 flex-wrap">
          <div className="relative flex-1 min-w-[200px]">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
            <input className="input pl-9" placeholder={t('searchPlaceholder')} value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <select className="input w-auto" value={branchFilter} onChange={e => setBranchFilter(e.target.value)}>
            <option value="all">{t('branch')}: {t('all')}</option>
            <option value="Chennai HQ">Chennai HQ</option>
            <option value="Coimbatore">Coimbatore</option>
            <option value="Madurai">Madurai</option>
          </select>
          <select className="input w-auto" value={statusFilter} onChange={e => setStatusFilter(e.target.value)}>
            <option value="all">{t('status')}: {t('all')}</option>
            <option value="active">{t('active')}</option>
            <option value="non_prized">{t('nonPrized')}</option>
            <option value="prized">{t('prized')}</option>
            <option value="partial">{t('partial')}</option>
            <option value="overdue">{t('overdue')}</option>
            <option value="defaulted">{t('defaulted')}</option>
          </select>
          <select className="input w-auto" value={prizeFilter} onChange={e => setPrizeFilter(e.target.value)}>
            <option value="all">{t('prizeStatus')}: {t('all')}</option>
            <option value="prized">{t('prized')}</option>
            <option value="non_prized">{t('nonPrized')}</option>
          </select>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: t('subscriber'), align: 'left' }, { label: t('name'), align: 'left' },
                    { label: t('phone'), align: 'left' }, { label: t('chit'), align: 'left' },
                    { label: t('ticketNo'), align: 'center' }, { label: t('status'), align: 'center' },
                    { label: t('totalPaid'), align: 'right' }, { label: t('outstandingCol'), align: 'right' },
                    { label: t('prizeStatus'), align: 'center' }, { label: t('lastPayment'), align: 'left' },
                    { label: '', align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(s => (
                  <tr key={s.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50 cursor-pointer" onClick={() => setSelected(s)}>
                    <td className="px-4 py-3 text-sm font-medium text-brand-700">{s.id}</td>
                    <td className="px-4 py-3 text-sm font-medium text-ink-900">{s.name}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{s.phone}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{s.chitGroupId}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">#{s.ticketNo}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={s.status} /></td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(s.totalPaid)}</td>
                    <td className="px-4 py-3 text-sm text-right tabular-nums">{s.outstanding > 0 ? <span className="text-red-600 font-medium">{formatINR(s.outstanding)}</span> : <span className="text-ink-400">—</span>}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={s.prizeStatus} /></td>
                    <td className="px-4 py-3 text-sm text-ink-600">{formatDate(s.lastPaymentDate)}</td>
                    <td className="px-4 py-3 text-center"><button onClick={(e) => { e.stopPropagation(); setSelected(s); }} className="text-brand-700 hover:text-brand-800"><Eye size={16} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <EmptyState title="No subscribers found" subtitle="Try adjusting your filters" />}
        </Card>
      </div>

      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected?.name || ''} size="xl">
        {selected && chitGroup && (
          <div className="space-y-5">
            {/* Header */}
            <div className="flex items-center justify-between flex-wrap gap-3 pb-4 border-b border-ink-200">
              <div>
                <h3 className="text-xl font-bold text-ink-900">{selected.name}</h3>
                <p className="text-sm text-ink-500">{selected.id} · {selected.phone}</p>
              </div>
              <StatusBadge status={selected.status} />
            </div>

            {/* Personal Info */}
            <div>
              <h4 className="font-semibold text-ink-900 mb-3">{t('personalInformation')}</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm">
                <div><p className="text-ink-500">{t('dateOfBirth')}</p><p className="font-medium text-ink-900">{formatDate(selected.dateOfBirth)}</p></div>
                <div><p className="text-ink-500">{t('phone')}</p><p className="font-medium text-ink-900">{selected.phone}</p></div>
                <div><p className="text-ink-500">{t('email')}</p><p className="font-medium text-ink-900 truncate">{selected.email}</p></div>
                <div className="col-span-2"><p className="text-ink-500">{t('address')}</p><p className="font-medium text-ink-900">{selected.address}</p></div>
                <div><p className="text-ink-500">{t('nominee')}</p><p className="font-medium text-ink-900">{selected.nominee}</p></div>
              </div>
            </div>

            {/* KYC */}
            <div>
              <h4 className="font-semibold text-ink-900 mb-3">{t('kyc')}</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div><p className="text-ink-500">{t('pan')}</p><p className="font-medium text-ink-900 font-mono">{maskPan(selected.pan)}</p></div>
                <div><p className="text-ink-500">{t('aadhaar')}</p><p className="font-medium text-ink-900 font-mono">{maskAadhaar(selected.aadhaar)}</p></div>
                <div><p className="text-ink-500">{t('addressProof')}</p><p className="font-medium text-ink-900">{selected.addressProof}</p></div>
                <div><p className="text-ink-500">{t('kycStatus')}</p><div className="pt-1"><StatusBadge status={selected.kycStatus} /></div></div>
              </div>
            </div>

            {/* Chit Details */}
            <div>
              <h4 className="font-semibold text-ink-900 mb-3">{t('chitDetails')}</h4>
              <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                <div><p className="text-ink-500">{t('chitGroup')}</p><p className="font-medium text-ink-900">{chitGroup.name}</p></div>
                <div><p className="text-ink-500">{t('ticketNumber')}</p><p className="font-medium text-ink-900">#{selected.ticketNo}</p></div>
                <div><p className="text-ink-500">{t('chitValue')}</p><p className="font-medium text-ink-900">{formatINR(chitGroup.chitValue)}</p></div>
                <div><p className="text-ink-500">{t('monthlyContribution')}</p><p className="font-medium text-ink-900">{formatINR(chitGroup.monthlyContribution)}</p></div>
                <div><p className="text-ink-500">{t('joiningDate')}</p><p className="font-medium text-ink-900">{formatDate(selected.joiningDate)}</p></div>
                <div><p className="text-ink-500">{t('currentMonth')}</p><p className="font-medium text-ink-900">M{chitGroup.currentMonth} / {chitGroup.duration}</p></div>
                <div><p className="text-ink-500">{t('prizeStatus')}</p><div className="pt-1"><StatusBadge status={selected.prizeStatus} /></div></div>
              </div>
            </div>

            {/* Financial Summary */}
            <div>
              <h4 className="font-semibold text-ink-900 mb-3">{t('financialSummary')}</h4>
              <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('totalPaid')}</p><p className="text-lg font-bold text-ink-900 tabular-nums">{formatINR(selected.totalPaid)}</p></div>
                <div className="bg-red-50 rounded-lg p-3"><p className="text-xs text-red-600">{t('outstandingCol')}</p><p className="text-lg font-bold text-red-700 tabular-nums">{formatINR(selected.outstanding)}</p></div>
                <div className="bg-brand-50 rounded-lg p-3"><p className="text-xs text-brand-700">{t('dividendReceived')}</p><p className="text-lg font-bold text-brand-800 tabular-nums">{formatINR(selected.dividendReceived)}</p></div>
                <div className="bg-gold-50 rounded-lg p-3"><p className="text-xs text-gold-700">{t('prizeAmount')}</p><p className="text-lg font-bold text-gold-800 tabular-nums">{selected.prizeAmount ? formatINR(selected.prizeAmount) : '—'}</p></div>
                <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('futureLiability')}</p><p className="text-lg font-bold text-ink-900 tabular-nums">{formatINR(selected.futureLiability)}</p></div>
              </div>
            </div>

            {/* Payment History */}
            <div>
              <h4 className="font-semibold text-ink-900 mb-3">{t('paymentHistory')}</h4>
              {subPayments.length > 0 ? (
                <div className="border border-ink-200 rounded-lg overflow-hidden">
                  <table className="w-full">
                    <thead className="bg-ink-50"><tr className="border-b border-ink-200">
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-left">{t('receiptNo')}</th>
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-center">{t('instalmentMonth')}</th>
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-right">{t('paid')}</th>
                      <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-center">{t('status')}</th>
                    </tr></thead>
                    <tbody>
                      {subPayments.map(p => (
                        <tr key={p.id} className="border-b border-ink-100 last:border-0">
                          <td className="px-3 py-2 text-sm text-brand-700">{p.receiptNo}</td>
                          <td className="px-3 py-2 text-sm text-ink-600 text-center">M{p.instalmentMonth}</td>
                          <td className="px-3 py-2 text-sm text-ink-900 text-right tabular-nums">{formatINR(p.paidAmount)}</td>
                          <td className="px-3 py-2 text-center"><StatusBadge status={p.status} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <p className="text-sm text-ink-400">{t('noData')}</p>}
            </div>

            {/* Documents */}
            {subDocs.length > 0 && (
              <div>
                <h4 className="font-semibold text-ink-900 mb-3">{t('documents')}</h4>
                <div className="flex flex-wrap gap-2">
                  {subDocs.map(d => (
                    <div key={d.id} className="flex items-center gap-2 px-3 py-2 rounded-lg border border-ink-200 bg-ink-50">
                      <FileText size={14} className="text-ink-400" />
                      <span className="text-sm text-ink-700">{d.name}</span>
                      <StatusBadge status={d.status} />
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Auction History */}
            {subAuctions.length > 0 && (
              <div>
                <h4 className="font-semibold text-ink-900 mb-3">{t('auctionHistoryLabel')}</h4>
                {subAuctions.map(a => (
                  <div key={a.id} className="flex items-center justify-between p-3 rounded-lg border border-ink-200 mb-2">
                    <div>
                      <p className="text-sm font-medium text-ink-900">{a.chitGroupName} - {t('month')} {a.month}</p>
                      <p className="text-xs text-ink-500">{t('prizeAmount')}: {a.prizeAmount ? formatINR(a.prizeAmount) : '—'}</p>
                    </div>
                    <StatusBadge status={a.status} />
                  </div>
                ))}
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { Card, CardHeader, CardBody, StatusBadge, Button, Modal, Input, EmptyState, InfoNote, CalculationRow } from '@/components/ui';
import { formatINR, formatDate } from '@/utils/format';
import { subscribers, chitGroups, payments, auctions, dividends } from '@/data/mockData';
import {
  Wallet, Bell, FileText, Gavel, Download, Home, Receipt, Trophy, Coins,
  ArrowLeft, CheckCircle, Menu, X, LogOut, Globe,
} from 'lucide-react';
import { cn } from '@/utils/cn';

export function CustomerPortal() {
  const { t, language, setLanguage, setRole } = useApp();
  const [page, setPage] = useState('home');
  const [showPayment, setShowPayment] = useState(false);
  const [paySuccess, setPaySuccess] = useState(false);
  const [payAmount, setPayAmount] = useState('');
  const [payMode, setPayMode] = useState('upi');
  const [mobileMenu, setMobileMenu] = useState(false);

  // Demo customer: Ravi Kumar
  const customer = subscribers[0];
  const chit = chitGroups.find(c => c.id === customer.chitGroupId)!;
  const custPayments = payments.filter(p => p.subscriberId === customer.id);
  const custAuctions = auctions.filter(a => a.chitGroupId === customer.chitGroupId);
  const custDividends = dividends.filter(d => d.chitGroupId === customer.chitGroupId);

  const navItems = [
    { id: 'home', label: t('myChit'), icon: Home },
    { id: 'payments', label: t('payments'), icon: Wallet },
    { id: 'receipts', label: t('viewReceipts'), icon: Receipt },
    { id: 'auction', label: t('auctionDetails'), icon: Gavel },
    { id: 'statement', label: t('downloadStatement'), icon: Download },
  ];

  const handlePay = () => {
    setPaySuccess(true);
    setTimeout(() => { setShowPayment(false); setPaySuccess(false); setPayAmount(''); }, 2000);
  };

  return (
    <div className="min-h-screen bg-ink-50">
      {/* Header */}
      <header className="bg-white border-b border-ink-200 sticky top-0 z-20">
        <div className="flex items-center justify-between px-4 py-3">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 rounded-lg bg-brand-700 flex items-center justify-center flex-shrink-0">
              <span className="text-gold-200 font-bold text-base font-display">L</span>
            </div>
            <div>
              <p className="font-display font-bold text-sm text-ink-900 leading-tight">{t('brandName')}</p>
              <p className="text-xs text-ink-500">{t('customerPortal')}</p>
            </div>
          </div>
          <div className="flex items-center gap-2">
            <div className="flex items-center rounded-lg border border-ink-200 overflow-hidden">
              <button onClick={() => setLanguage('en')} className={cn('px-2.5 py-1 text-xs font-medium', language === 'en' ? 'bg-brand-700 text-white' : 'text-ink-600')}>EN</button>
              <button onClick={() => setLanguage('ta')} className={cn('px-2.5 py-1 text-xs font-medium', language === 'ta' ? 'bg-brand-700 text-white' : 'text-ink-600')}>த</button>
            </div>
            <button onClick={() => setRole(null)} className="p-2 rounded-lg text-ink-400 hover:bg-ink-100 hover:text-ink-900"><LogOut size={18} /></button>
            <button onClick={() => setMobileMenu(!mobileMenu)} className="md:hidden p-2 rounded-lg text-ink-600 hover:bg-ink-100"><Menu size={20} /></button>
          </div>
        </div>
      </header>

      <div className="max-w-4xl mx-auto p-4 flex gap-6">
        {/* Sidebar nav */}
        <nav className="hidden md:block w-48 flex-shrink-0 py-4 space-y-1">
          {navItems.map(item => {
            const Icon = item.icon;
            return (
              <button key={item.id} onClick={() => setPage(item.id)}
                className={cn('flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium w-full transition-colors',
                  page === item.id ? 'bg-brand-50 text-brand-800' : 'text-ink-600 hover:bg-ink-100')}>
                <Icon size={18} /> {item.label}
              </button>
            );
          })}
        </nav>

        {/* Mobile nav */}
        {mobileMenu && (
          <div className="md:hidden fixed inset-0 z-30 bg-ink-950/30" onClick={() => setMobileMenu(false)}>
            <div className="absolute top-0 right-0 w-64 h-full bg-white p-4 space-y-1" onClick={e => e.stopPropagation()}>
              <button onClick={() => setMobileMenu(false)} className="mb-2 p-1 rounded-lg hover:bg-ink-100"><X size={20} /></button>
              {navItems.map(item => {
                const Icon = item.icon;
                return (
                  <button key={item.id} onClick={() => { setPage(item.id); setMobileMenu(false); }}
                    className={cn('flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium w-full', page === item.id ? 'bg-brand-50 text-brand-800' : 'text-ink-600')}>
                    <Icon size={18} /> {item.label}
                  </button>
                );
              })}
            </div>
          </div>
        )}

        {/* Content */}
        <div className="flex-1 py-4 space-y-4 min-w-0">
          {page === 'home' && (
            <>
              <div>
                <p className="text-sm text-ink-500">{t('welcome')},</p>
                <h1 className="text-2xl font-bold text-ink-900 font-display">{customer.name}</h1>
              </div>

              {/* My Chit */}
              <Card>
                <CardHeader title={t('myChit')} action={<StatusBadge status={customer.prizeStatus} />} />
                <CardBody>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                    <div><p className="text-ink-500">{t('chitValue')}</p><p className="font-bold text-ink-900">{formatINR(chit.chitValue)}</p></div>
                    <div><p className="text-ink-500">{t('monthlyContribution')}</p><p className="font-bold text-ink-900">{formatINR(chit.monthlyContribution)}</p></div>
                    <div><p className="text-ink-500">{t('currentMonth')}</p><p className="font-bold text-ink-900">M{chit.currentMonth} / {chit.duration}</p></div>
                    <div><p className="text-ink-500">{t('status')}</p><div className="pt-1"><StatusBadge status={chit.status} /></div></div>
                  </div>
                </CardBody>
              </Card>

              {/* Payment Summary */}
              <Card>
                <CardHeader title={t('paymentSummary')} />
                <CardBody>
                  <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
                    <div className="bg-brand-50 rounded-lg p-3"><p className="text-xs text-brand-700">{t('totalPaid')}</p><p className="text-lg font-bold text-brand-800 tabular-nums">{formatINR(customer.totalPaid)}</p></div>
                    <div className="bg-red-50 rounded-lg p-3"><p className="text-xs text-red-600">{t('outstandingCol')}</p><p className="text-lg font-bold text-red-700 tabular-nums">{formatINR(customer.outstanding)}</p></div>
                    <div className="bg-gold-50 rounded-lg p-3"><p className="text-xs text-gold-700">{t('nextDue')}</p><p className="text-lg font-bold text-gold-800 tabular-nums">{formatINR(chit.monthlyContribution)}</p></div>
                    <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('dueDate')}</p><p className="text-sm font-bold text-ink-900">{formatDate('2026-09-10')}</p></div>
                  </div>
                  <div className="mt-4 flex gap-2 flex-wrap">
                    <Button onClick={() => setShowPayment(true)}><Wallet size={16} /> {t('payNow')}</Button>
                    <Button variant="secondary" onClick={() => setPage('payments')}>{t('viewPayments')}</Button>
                    <Button variant="secondary" onClick={() => setPage('receipts')}>{t('viewReceipts')}</Button>
                  </div>
                </CardBody>
              </Card>

              {/* Prize */}
              {customer.prizeStatus === 'prized' && (
                <Card>
                  <CardHeader title={t('prizeAmount')} action={<StatusBadge status="prized" />} />
                  <CardBody>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                      <div><p className="text-ink-500">{t('prizeAmount')}</p><p className="font-bold text-brand-700">{customer.prizeAmount ? formatINR(customer.prizeAmount) : '—'}</p></div>
                      <div><p className="text-ink-500">{t('prizeMonth')}</p><p className="font-bold text-ink-900">M{customer.prizeMonth}</p></div>
                      <div><p className="text-ink-500">{t('futureLiability')}</p><p className="font-bold text-red-600">{formatINR(customer.futureLiability)}</p></div>
                    </div>
                    <InfoNote>{t('futureLiabilityNote')}</InfoNote>
                  </CardBody>
                </Card>
              )}

              {/* Dividend */}
              <Card>
                <CardHeader title={t('dividends')} />
                <CardBody>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3">
                    <div className="bg-brand-50 rounded-lg p-3"><p className="text-xs text-brand-700">{t('dividendReceived')}</p><p className="text-lg font-bold text-brand-800 tabular-nums">{formatINR(customer.dividendReceived)}</p></div>
                    <div className="bg-ink-50 rounded-lg p-3"><p className="text-xs text-ink-500">{t('dividendPerSubscriber')}</p><p className="text-lg font-bold text-ink-900 tabular-nums">{formatINR(7500)}</p></div>
                  </div>
                </CardBody>
              </Card>

              {/* Notifications */}
              <Card>
                <CardHeader title={t('notifications')} />
                <CardBody>
                  <div className="space-y-2">
                    {[
                      { msg: language === 'ta' ? 'உங்கள் ₹50,000 தவணை 10 செப் தேதி செலுத்த வேண்டும்.' : 'Your instalment of ₹50,000 is due on 10 Sep.', icon: Bell },
                      { msg: language === 'ta' ? 'CHIT-1001 ஏலம் செப் 15 அன்று திட்டமிடப்பட்டுள்ளது.' : 'Auction for CHIT-1001 is scheduled on 15 Sep.', icon: Gavel },
                    ].map((n, i) => {
                      const Icon = n.icon;
                      return (
                        <div key={i} className="flex items-start gap-3 p-3 rounded-lg bg-ink-50">
                          <Icon size={16} className="text-ink-400 mt-0.5 flex-shrink-0" />
                          <p className="text-sm text-ink-700">{n.msg}</p>
                        </div>
                      );
                    })}
                  </div>
                </CardBody>
              </Card>
            </>
          )}

          {page === 'payments' && (
            <Card>
              <CardHeader title={t('paymentHistory')} action={<Button variant="secondary" onClick={() => setShowPayment(true)}><Wallet size={16} /> {t('payNow')}</Button>} />
              {custPayments.length > 0 ? (
                <div className="overflow-x-auto">
                  <table className="w-full">
                    <thead><tr className="border-b border-ink-200">
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-left">{t('receiptNo')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-center">{t('instalmentMonth')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-right">{t('paid')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-left">{t('paymentMode')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-left">{t('date')}</th>
                      <th className="px-4 py-3 text-xs font-semibold text-ink-500 uppercase text-center">{t('status')}</th>
                    </tr></thead>
                    <tbody>
                      {custPayments.map(p => (
                        <tr key={p.id} className="border-b border-ink-100 last:border-0">
                          <td className="px-4 py-3 text-sm font-medium text-brand-700">{p.receiptNo}</td>
                          <td className="px-4 py-3 text-sm text-ink-600 text-center">M{p.instalmentMonth}</td>
                          <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(p.paidAmount)}</td>
                          <td className="px-4 py-3 text-sm text-ink-600 capitalize">{p.paymentMode.replace('_', ' ')}</td>
                          <td className="px-4 py-3 text-sm text-ink-600">{formatDate(p.paymentDate)}</td>
                          <td className="px-4 py-3 text-center"><StatusBadge status={p.status} /></td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : <EmptyState title="No payment history" />}
            </Card>
          )}

          {page === 'receipts' && (
            <div className="space-y-4">
              {custPayments.map(p => (
                <Card key={p.id}>
                  <CardBody>
                    <div className="flex items-center justify-between mb-3">
                      <div className="flex items-center gap-2"><Receipt size={18} className="text-brand-700" /><span className="font-medium text-ink-900">{p.receiptNo}</span></div>
                      <StatusBadge status={p.status} />
                    </div>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                      <div><p className="text-ink-500">{t('chit')}</p><p className="font-medium text-ink-900">{p.chitGroupName}</p></div>
                      <div><p className="text-ink-500">{t('instalmentMonth')}</p><p className="font-medium text-ink-900">M{p.instalmentMonth}</p></div>
                      <div><p className="text-ink-500">{t('amount')}</p><p className="font-bold text-brand-700">{formatINR(p.paidAmount)}</p></div>
                      <div><p className="text-ink-500">{t('date')}</p><p className="font-medium text-ink-900">{formatDate(p.paymentDate)}</p></div>
                    </div>
                    <div className="flex gap-2 mt-3">
                      <Button variant="secondary" onClick={() => window.print()}><Download size={14} /> {t('download')}</Button>
                    </div>
                  </CardBody>
                </Card>
              ))}
              {custPayments.length === 0 && <EmptyState title="No receipts found" />}
            </div>
          )}

          {page === 'auction' && (
            <div className="space-y-4">
              {custAuctions.map(a => (
                <Card key={a.id}>
                  <CardHeader title={`${a.chitGroupName} - ${t('month')} ${a.month}`} action={<StatusBadge status={a.status} />} />
                  <CardBody>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-3 text-sm">
                      <div><p className="text-ink-500">{t('chitAmount')}</p><p className="font-bold text-ink-900">{formatINR(a.chitAmount)}</p></div>
                      <div><p className="text-ink-500">{t('highestDiscount')}</p><p className="font-bold text-ink-900">{a.highestDiscount > 0 ? formatINR(a.highestDiscount) : '—'}</p></div>
                      <div><p className="text-ink-500">{t('winner')}</p><p className="font-medium text-ink-900">{a.winnerName || '—'}</p></div>
                      <div><p className="text-ink-500">{t('prizeAmount')}</p><p className="font-bold text-brand-700">{a.prizeAmount ? formatINR(a.prizeAmount) : '—'}</p></div>
                    </div>
                  </CardBody>
                </Card>
              ))}
            </div>
          )}

          {page === 'statement' && (
            <Card>
              <CardHeader title={t('downloadStatement')} />
              <CardBody>
                <div className="space-y-4">
                  <div className="bg-ink-50 rounded-lg p-4 space-y-2 text-sm">
                    <div className="flex justify-between"><span className="text-ink-500">{t('subscriber')}</span><span className="font-medium">{customer.name} ({customer.id})</span></div>
                    <div className="flex justify-between"><span className="text-ink-500">{t('chit')}</span><span className="font-medium">{chit.name} ({chit.id})</span></div>
                    <div className="flex justify-between"><span className="text-ink-500">{t('totalPaid')}</span><span className="font-bold tabular-nums">{formatINR(customer.totalPaid)}</span></div>
                    <div className="flex justify-between"><span className="text-ink-500">{t('outstandingCol')}</span><span className="font-bold tabular-nums text-red-600">{formatINR(customer.outstanding)}</span></div>
                    <div className="flex justify-between"><span className="text-ink-500">{t('dividendReceived')}</span><span className="font-bold tabular-nums">{formatINR(customer.dividendReceived)}</span></div>
                    <div className="flex justify-between"><span className="text-ink-500">{t('prizeAmount')}</span><span className="font-bold tabular-nums">{customer.prizeAmount ? formatINR(customer.prizeAmount) : '—'}</span></div>
                    <div className="flex justify-between"><span className="text-ink-500">{t('futureLiability')}</span><span className="font-bold tabular-nums">{formatINR(customer.futureLiability)}</span></div>
                  </div>
                  <Button onClick={() => window.print()}><Download size={16} /> {t('downloadStatement')}</Button>
                </div>
              </CardBody>
            </Card>
          )}
        </div>
      </div>

      {/* Payment Modal */}
      <Modal open={showPayment} onClose={() => { setShowPayment(false); setPaySuccess(false); setPayAmount(''); }} title={t('payNow')} size="sm">
        {paySuccess ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-full bg-brand-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} className="text-brand-600" />
            </div>
            <h3 className="text-lg font-bold text-ink-900 mb-2">{t('paymentReceived')}</h3>
            <p className="text-sm text-ink-500">{formatINR(Number(payAmount) || 0)}</p>
          </div>
        ) : (
          <div className="space-y-4">
            <div className="bg-ink-50 rounded-lg p-3 flex justify-between items-center">
              <span className="text-sm text-ink-500">{t('dueAmount')}</span>
              <span className="text-lg font-bold text-ink-900 tabular-nums">{formatINR(chit.monthlyContribution)}</span>
            </div>
            <Input label={t('enterAmount')} type="number" value={payAmount} onChange={setPayAmount} placeholder="50000" required />
            <div>
              <label className="label">{t('paymentMethod')}</label>
              <div className="grid grid-cols-3 gap-2">
                {[t('upi'), t('bankTransfer'), t('other')].map((m, i) => (
                  <button key={m} onClick={() => setPayMode(['upi', 'bank_transfer', 'other'][i])}
                    className={cn('px-3 py-2.5 rounded-lg border text-sm font-medium transition-colors',
                      payMode === ['upi', 'bank_transfer', 'other'][i] ? 'border-brand-500 bg-brand-50 text-brand-800' : 'border-ink-200 text-ink-600 hover:bg-ink-50')}>
                    {m}
                  </button>
                ))}
              </div>
            </div>
            <InfoNote>{t('securePaymentConfirmation')}</InfoNote>
            <Button className="w-full" disabled={!payAmount || Number(payAmount) <= 0} onClick={handlePay}>{t('confirm')} {t('payNow')}</Button>
          </div>
        )}
      </Modal>
    </div>
  );
}

import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { TopBar } from '@/components/Layout';
import { Card, CardHeader, CardBody, StatusBadge, Button, Modal, Input, Select, InfoNote, CalculationRow, HowCalculated, EmptyState } from '@/components/ui';
import { KPICard } from '@/components/Table';
import { formatINR, formatDate, formatDateTime } from '@/utils/format';
import { auctions, chitGroups, subscribers } from '@/data/mockData';
import {
  calculateDiscountPercentage, calculatePrizeAmount, calculateForemanCommission,
  calculateDividendPool, calculateDividendPerMember, calculateRemainingMonths, calculateFutureLiability,
} from '@/utils/calculations';
import { Gavel, Trophy, Users, Calendar, Check, X, FileText, AlertTriangle, Plus, Eye } from 'lucide-react';
import type { Auction, AuctionBid } from '@/types';

export function AuctionPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [tab, setTab] = useState('all');
  const [selected, setSelected] = useState<Auction | null>(null);
  const [bids, setBids] = useState<AuctionBid[]>([]);
  const [newBidSub, setNewBidSub] = useState('');
  const [newBidAmount, setNewBidAmount] = useState('');

  const todayCount = auctions.filter(a => a.date === '2026-09-07').length;
  const upcomingCount = auctions.filter(a => a.status === 'scheduled').length;
  const completedCount = auctions.filter(a => a.status === 'completed').length;
  const pendingCount = auctions.filter(a => a.status === 'pending_approval').length;

  const filtered = auctions.filter(a => {
    if (tab === 'all') return true;
    if (tab === 'today') return a.date === '2026-09-07';
    if (tab === 'upcoming') return a.status === 'scheduled';
    if (tab === 'completed') return a.status === 'completed';
    if (tab === 'pending') return a.status === 'pending_approval';
    return true;
  });

  const openAuction = (auc: Auction) => {
    setSelected(auc);
    setBids(auc.bids);
  };

  const chitGroup = selected ? chitGroups.find(c => c.id === selected.chitGroupId) : null;
  const eligibleSubs = selected ? subscribers.filter(s => s.chitGroupId === selected.chitGroupId && s.prizeStatus !== 'prized').slice(0, 10) : [];

  const highestBid = bids.length > 0 ? Math.max(...bids.map(b => b.bidDiscount)) : 0;
  const discountPct = selected ? calculateDiscountPercentage(selected.chitAmount, highestBid) : 0;
  const prizeAmt = selected ? calculatePrizeAmount(selected.chitAmount, highestBid) : 0;
  const commission = selected && chitGroup ? calculateForemanCommission(selected.chitAmount, chitGroup.commissionPercent) : 0;
  const divPool = calculateDividendPool(highestBid, commission);
  const divPerMember = chitGroup ? calculateDividendPerMember(divPool, chitGroup.members) : 0;
  const remainingMonths = chitGroup ? calculateRemainingMonths(chitGroup.duration, selected?.month || 0) : 0;
  const futureLiability = calculateFutureLiability(remainingMonths, chitGroup?.monthlyContribution || 0);

  // Check for ties
  const topBids = bids.filter(b => b.bidDiscount === highestBid);
  const hasTie = topBids.length > 1;

  const addBid = () => {
    if (!newBidSub || !newBidAmount) return;
    const sub = subscribers.find(s => s.id === newBidSub);
    if (!sub) return;
    setBids([...bids, {
      subscriberId: sub.id, subscriberName: sub.name, ticketNo: sub.ticketNo,
      bidDiscount: Number(newBidAmount), submittedAt: new Date().toISOString(), status: 'pending',
    }]);
    setNewBidSub(''); setNewBidAmount('');
  };

  const selectWinner = () => {
    if (hasTie) return;
    setBids(bids.map(b => ({ ...b, status: b.bidDiscount === highestBid ? 'winner' : 'rejected' })));
  };

  return (
    <div>
      <TopBar title={t('auctions')} subtitle={t('auctionDashboard')} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard label={t('todaysAuctions')} value={String(todayCount)} icon={<Calendar size={18} />} />
          <KPICard label={t('upcomingAuctions')} value={String(upcomingCount)} icon={<Gavel size={18} />} accent="gold" />
          <KPICard label={t('completedAuctions')} value={String(completedCount)} icon={<Check size={18} />} />
          <KPICard label={t('pendingApproval')} value={String(pendingCount)} icon={<AlertTriangle size={18} />} accent="gold" />
        </div>

        <div className="flex gap-2 flex-wrap">
          {[
            { key: 'all', label: t('all') }, { key: 'today', label: t('todaysAuctions') },
            { key: 'upcoming', label: t('upcomingAuctions') }, { key: 'completed', label: t('completedAuctions') },
            { key: 'pending', label: t('pendingApproval') },
          ].map(tb => (
            <button key={tb.key} onClick={() => setTab(tb.key)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors ${tab === tb.key ? 'bg-brand-700 text-white' : 'bg-white text-ink-600 border border-ink-200 hover:bg-ink-50'}`}>
              {tb.label}
            </button>
          ))}
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: t('auctionId'), align: 'left' }, { label: t('chitGroup'), align: 'left' },
                    { label: t('month'), align: 'center' }, { label: t('date'), align: 'left' },
                    { label: t('chitAmount'), align: 'right' }, { label: t('eligibleSubscribers'), align: 'center' },
                    { label: t('highestDiscount'), align: 'right' }, { label: t('winner'), align: 'left' },
                    { label: t('prizeAmount'), align: 'right' }, { label: t('status'), align: 'center' },
                    { label: '', align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(a => (
                  <tr key={a.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50 cursor-pointer" onClick={() => openAuction(a)}>
                    <td className="px-4 py-3 text-sm font-medium text-brand-700">{a.id}</td>
                    <td className="px-4 py-3 text-sm text-ink-900">{a.chitGroupName}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">M{a.month}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{formatDate(a.date)}</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums">{formatINR(a.chitAmount)}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">{a.eligibleSubscribers}</td>
                    <td className="px-4 py-3 text-sm text-right tabular-nums">{a.highestDiscount > 0 ? formatINR(a.highestDiscount) : '—'}</td>
                    <td className="px-4 py-3 text-sm text-ink-900">{a.winnerName || '—'}</td>
                    <td className="px-4 py-3 text-sm text-right tabular-nums">{a.prizeAmount ? formatINR(a.prizeAmount) : '—'}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={a.status} /></td>
                    <td className="px-4 py-3 text-center"><button onClick={(e) => { e.stopPropagation(); openAuction(a); }} className="text-brand-700 hover:text-brand-800"><Eye size={16} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <EmptyState title="No auctions found" />}
        </Card>
      </div>

      {/* Auction Detail Modal */}
      <Modal open={!!selected} onClose={() => setSelected(null)} title={selected ? `${selected.id} - ${selected.chitGroupName}` : ''} size="xl">
        {selected && chitGroup && (
          <div className="space-y-5">
            {/* Auction Info */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('chitAmount')}</p><p className="font-bold text-ink-900">{formatINR(selected.chitAmount)}</p></div>
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('currentMonth')}</p><p className="font-bold text-ink-900">M{selected.month}</p></div>
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('eligibleMembers')}</p><p className="font-bold text-ink-900">{selected.eligibleSubscribers}</p></div>
              <div className="bg-ink-50 rounded-lg p-3"><p className="kpi-label">{t('date')}</p><p className="font-bold text-ink-900">{formatDate(selected.date)}</p></div>
            </div>

            {/* Bid Entry */}
            <div>
              <h4 className="font-semibold text-ink-900 mb-3">{t('enterBids')}</h4>
              <div className="flex gap-2 mb-3">
                <select className="input flex-1" value={newBidSub} onChange={e => setNewBidSub(e.target.value)}>
                  <option value="">Select subscriber...</option>
                  {eligibleSubs.map(s => <option key={s.id} value={s.id}>{s.name} (#{s.ticketNo})</option>)}
                </select>
                <input className="input w-40" type="number" placeholder="Bid Discount (₹)" value={newBidAmount} onChange={e => setNewBidAmount(e.target.value)} />
                <Button onClick={addBid}><Plus size={16} /> {t('addBid')}</Button>
              </div>
              <div className="border border-ink-200 rounded-lg overflow-hidden">
                <table className="w-full">
                  <thead className="bg-ink-50"><tr className="border-b border-ink-200">
                    <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-left">{t('subscriber')}</th>
                    <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-right">{t('bidDiscount')}</th>
                    <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-left">{t('submittedAt')}</th>
                    <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-center">{t('status')}</th>
                  </tr></thead>
                  <tbody>
                    {bids.length === 0 ? (
                      <tr><td colSpan={4} className="px-3 py-6 text-center text-sm text-ink-400">{t('noData')}</td></tr>
                    ) : bids.map((b, i) => (
                      <tr key={i} className="border-b border-ink-100 last:border-0">
                        <td className="px-3 py-2 text-sm text-ink-900">{b.subscriberName} (#{b.ticketNo})</td>
                        <td className="px-3 py-2 text-sm text-ink-900 text-right tabular-nums font-medium">{formatINR(b.bidDiscount)}</td>
                        <td className="px-3 py-2 text-sm text-ink-600">{formatDateTime(b.submittedAt)}</td>
                        <td className="px-3 py-2 text-center"><StatusBadge status={b.status} /></td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>

            {/* Tie warning */}
            {hasTie && (
              <div className="flex items-start gap-3 p-3 rounded-lg bg-gold-50 border border-gold-200">
                <AlertTriangle size={18} className="text-gold-700 mt-0.5 flex-shrink-0" />
                <p className="text-sm text-gold-800">{t('manualReviewRequired')}</p>
              </div>
            )}

            {/* Auction Calculation */}
            {highestBid > 0 && (
              <Card>
                <CardHeader title={t('auctionCalculation')} />
                <CardBody>
                  <CalculationRow label={t('chitAmount')} value={formatINR(selected.chitAmount)} />
                  <CalculationRow label={t('auctionDiscount')} value={formatINR(highestBid)} />
                  <CalculationRow label={t('discountPercent')} value={`${discountPct.toFixed(1)}%`} />
                  <CalculationRow label={t('prizeAmount')} value={formatINR(prizeAmt)} bold />
                  <HowCalculated>
                    {t('prizeAmount')} = {t('chitAmount')} − {t('auctionDiscount')} = {formatINR(selected.chitAmount)} − {formatINR(highestBid)} = <strong>{formatINR(prizeAmt)}</strong>
                  </HowCalculated>
                </CardBody>
              </Card>
            )}

            {/* Commission */}
            {highestBid > 0 && (
              <Card>
                <CardHeader title={t('foremanCommission')} />
                <CardBody>
                  <CalculationRow label={t('commissionRate')} value={`${chitGroup.commissionPercent}%`} />
                  <CalculationRow label={t('commissionBase')} value={formatINR(selected.chitAmount)} />
                  <CalculationRow label={t('foremanCommission')} value={formatINR(commission)} bold />
                  <InfoNote>{t('commissionNote2')}</InfoNote>
                </CardBody>
              </Card>
            )}

            {/* Dividend */}
            {highestBid > 0 && (
              <Card>
                <CardHeader title={t('dividends')} />
                <CardBody>
                  <CalculationRow label={t('auctionDiscount')} value={formatINR(highestBid)} />
                  <CalculationRow label={t('foremanCommission')} value={formatINR(commission)} />
                  <CalculationRow label={t('potentialDistributableAmount')} value={formatINR(divPool)} bold />
                  <CalculationRow label={t('subscribersCount')} value={String(chitGroup.members)} />
                  <CalculationRow label={t('illustrativeDividend')} value={formatINR(divPerMember)} bold />
                  <InfoNote>{t('dividendNote')}</InfoNote>
                </CardBody>
              </Card>
            )}

            {/* Prize Result */}
            {selected.status === 'completed' || selected.status === 'pending_approval' ? (
              <Card>
                <CardHeader title={t('prizeAmount')} action={<StatusBadge status={selected.status} />} />
                <CardBody>
                  <div className="grid grid-cols-2 md:grid-cols-3 gap-3 text-sm mb-4">
                    <div><p className="text-ink-500">{t('winner')}</p><p className="font-bold text-ink-900">{selected.winnerName}</p></div>
                    <div><p className="text-ink-500">{t('chitValue')}</p><p className="font-bold text-ink-900">{formatINR(selected.chitAmount)}</p></div>
                    <div><p className="text-ink-500">{t('auctionMonth')}</p><p className="font-bold text-ink-900">M{selected.month}</p></div>
                    <div><p className="text-ink-500">{t('discount')}</p><p className="font-bold text-ink-900">{formatINR(selected.highestDiscount)}</p></div>
                    <div><p className="text-ink-500">{t('prizeAmount')}</p><p className="font-bold text-brand-700">{selected.prizeAmount ? formatINR(selected.prizeAmount) : formatINR(prizeAmt)}</p></div>
                    <div><p className="text-ink-500">{t('commission')}</p><p className="font-bold text-ink-900">{selected.commission ? formatINR(selected.commission) : formatINR(commission)}</p></div>
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <Button variant="secondary">{t('review')}</Button>
                    <Button variant="primary" onClick={() => onNavigate('prizePayments')}><Check size={16} /> {t('approve')}</Button>
                    <Button variant="danger"><X size={16} /> {t('reject')}</Button>
                    <Button variant="ghost"><FileText size={16} /> {t('generatePrizeStatement')}</Button>
                  </div>
                </CardBody>
              </Card>
            ) : null}

            {/* Post-Prize Liability */}
            {highestBid > 0 && (
              <Card>
                <CardHeader title={t('futureSubscriptionLiability')} />
                <CardBody>
                  <div className="bg-brand-50 border border-brand-200 rounded-lg p-4 mb-3">
                    <p className="text-sm text-brand-700 mb-1">{t('futureSubscriptionLiability')}</p>
                    <p className="text-3xl font-bold text-brand-800 tabular-nums">{formatINR(futureLiability)}</p>
                  </div>
                  <div className="grid grid-cols-3 gap-3 text-sm mb-4">
                    <div><p className="text-ink-500">{t('duration')}</p><p className="font-medium">{chitGroup.duration} {t('month').toLowerCase()}s</p></div>
                    <div><p className="text-ink-500">{t('remainingMonths')}</p><p className="font-medium">{remainingMonths}</p></div>
                    <div><p className="text-ink-500">{t('monthlyContribution')}</p><p className="font-medium">{formatINR(chitGroup.monthlyContribution)}</p></div>
                  </div>
                  <InfoNote>{t('futureLiabilityNote')}</InfoNote>
                  <div className="mt-3 border border-ink-200 rounded-lg overflow-hidden max-h-48 overflow-y-auto">
                    <table className="w-full">
                      <thead className="bg-ink-50 sticky top-0"><tr className="border-b border-ink-200">
                        <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-left">{t('month')}</th>
                        <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-right">{t('amount')}</th>
                        <th className="px-3 py-2 text-xs font-semibold text-ink-500 uppercase text-center">{t('status')}</th>
                      </tr></thead>
                      <tbody>
                        {Array.from({ length: remainingMonths }, (_, i) => (
                          <tr key={i} className="border-b border-ink-100 last:border-0">
                            <td className="px-3 py-2 text-sm text-ink-700">{t('month')} {selected.month + i + 1}</td>
                            <td className="px-3 py-2 text-sm text-ink-900 text-right tabular-nums">{formatINR(chitGroup.monthlyContribution)}</td>
                            <td className="px-3 py-2 text-center"><StatusBadge status="pending" /></td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </CardBody>
              </Card>
            )}

            {/* Actions */}
            {selected.status === 'scheduled' && bids.length > 0 && !hasTie && (
              <div className="flex justify-end gap-2">
                <Button variant="secondary" onClick={() => setSelected(null)}>{t('cancel')}</Button>
                <Button variant="primary" onClick={selectWinner}><Trophy size={16} /> {t('selectWinner')}</Button>
              </div>
            )}
          </div>
        )}
      </Modal>
    </div>
  );
}

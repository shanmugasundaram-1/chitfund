import { useState } from 'react';
import { useApp } from '@/context/AppContext';
import { TopBar } from '@/components/Layout';
import { Card, StatusBadge, Button, Modal, Input, Select, EmptyState } from '@/components/ui';
import { KPICard } from '@/components/Table';
import { formatINR, formatDate } from '@/utils/format';
import { payments, subscribers, chitGroups } from '@/data/mockData';
import { calculateOutstanding } from '@/utils/calculations';
import { Plus, Search, Eye, Printer, Download, Share2, CheckCircle, Wallet } from 'lucide-react';
import type { Payment, PaymentMode } from '@/types';

export function PaymentsPage({ onNavigate }: { onNavigate: (page: string) => void }) {
  const { t } = useApp();
  const [search, setSearch] = useState('');
  const [showEntry, setShowEntry] = useState(false);
  const [showReceipt, setShowReceipt] = useState<Payment | null>(null);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [form, setForm] = useState({
    subscriberId: '', instalmentMonth: '', paidAmount: '', paymentMode: 'upi',
    paymentDate: '2026-09-07', transactionRef: '', notes: '',
  });
  const [errors, setErrors] = useState<Record<string, string>>({});

  const filtered = payments.filter(p =>
    p.subscriberName.toLowerCase().includes(search.toLowerCase()) ||
    p.receiptNo.toLowerCase().includes(search.toLowerCase()) ||
    p.chitGroupName.toLowerCase().includes(search.toLowerCase())
  );

  const totalCollected = payments.reduce((sum, p) => sum + p.paidAmount, 0);
  const totalOutstanding = payments.reduce((sum, p) => sum + p.outstanding, 0);

  const selectedSub = subscribers.find(s => s.id === form.subscriberId);
  const selectedChit = selectedSub ? chitGroups.find(c => c.id === selectedSub.chitGroupId) : null;
  const dueAmount = selectedChit?.monthlyContribution || 0;
  const paidAmt = Number(form.paidAmount) || 0;
  const outstanding = calculateOutstanding(dueAmount, paidAmt);
  const payStatus = paidAmt === 0 ? 'pending' : outstanding === 0 ? 'paid' : 'partial';

  const validate = (): boolean => {
    const e: Record<string, string> = {};
    if (!form.subscriberId) e.subscriberId = 'Subscriber is required';
    if (!form.instalmentMonth) e.instalmentMonth = 'Instalment month is required';
    if (!form.paidAmount || paidAmt <= 0) e.paidAmount = 'Payment amount must be positive';
    if (paidAmt > dueAmount) e.paidAmount = 'Payment cannot exceed due amount';
    setErrors(e);
    return Object.keys(e).length === 0;
  };

  const handleSubmit = () => {
    if (validate()) {
      setPaymentSuccess(true);
    }
  };

  const closeEntry = () => {
    setShowEntry(false);
    setPaymentSuccess(false);
    setForm({ subscriberId: '', instalmentMonth: '', paidAmount: '', paymentMode: 'upi', paymentDate: '2026-09-07', transactionRef: '', notes: '' });
    setErrors({});
  };

  return (
    <div>
      <TopBar title={t('payments')} subtitle={`${payments.length} ${t('payments').toLowerCase()}`} />
      <div className="p-4 lg:p-6 space-y-4">
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <KPICard label={t('totalPaid')} value={formatINR(totalCollected, { compact: true })} icon={<Wallet size={18} />} />
          <KPICard label={t('outstandingCol')} value={formatINR(totalOutstanding, { compact: true })} icon={<Wallet size={18} />} accent="gold" />
          <KPICard label={t('paid')} value={String(payments.filter(p => p.status === 'paid').length)} icon={<CheckCircle size={18} />} />
          <KPICard label={t('partial')} value={String(payments.filter(p => p.status === 'partial').length)} icon={<Wallet size={18} />} accent="gold" />
        </div>

        <div className="flex flex-col sm:flex-row gap-3 justify-between">
          <div className="relative flex-1 max-w-xl">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-400" />
            <input className="input pl-9" placeholder={t('searchPlaceholder')} value={search} onChange={e => setSearch(e.target.value)} />
          </div>
          <Button onClick={() => setShowEntry(true)}><Plus size={16} /> {t('recordPayment')}</Button>
        </div>

        <Card>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b border-ink-200">
                  {[
                    { label: t('receiptNo'), align: 'left' }, { label: t('subscriber'), align: 'left' },
                    { label: t('chit'), align: 'left' }, { label: t('instalmentMonth'), align: 'center' },
                    { label: t('dueAmount'), align: 'right' }, { label: t('paid'), align: 'right' },
                    { label: t('outstandingCol'), align: 'right' }, { label: t('paymentMode'), align: 'left' },
                    { label: t('date'), align: 'left' }, { label: t('status'), align: 'center' },
                    { label: '', align: 'center' },
                  ].map((h, i) => (
                    <th key={i} className={`px-4 py-3 text-xs font-semibold text-ink-500 uppercase tracking-wide whitespace-nowrap text-${h.align}`}>{h.label}</th>
                  ))}
                </tr>
              </thead>
              <tbody>
                {filtered.map(p => (
                  <tr key={p.id} className="border-b border-ink-100 last:border-0 hover:bg-ink-50">
                    <td className="px-4 py-3 text-sm font-medium text-brand-700">{p.receiptNo}</td>
                    <td className="px-4 py-3 text-sm text-ink-900">{p.subscriberName}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{p.chitGroupName}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 text-center">M{p.instalmentMonth}</td>
                    <td className="px-4 py-3 text-sm text-ink-700 text-right tabular-nums">{formatINR(p.dueAmount)}</td>
                    <td className="px-4 py-3 text-sm text-ink-900 text-right tabular-nums font-medium">{formatINR(p.paidAmount)}</td>
                    <td className="px-4 py-3 text-sm text-right tabular-nums">{p.outstanding > 0 ? <span className="text-red-600">{formatINR(p.outstanding)}</span> : <span className="text-ink-400">—</span>}</td>
                    <td className="px-4 py-3 text-sm text-ink-600 capitalize">{p.paymentMode.replace('_', ' ')}</td>
                    <td className="px-4 py-3 text-sm text-ink-600">{formatDate(p.paymentDate)}</td>
                    <td className="px-4 py-3 text-center"><StatusBadge status={p.status} /></td>
                    <td className="px-4 py-3 text-center"><button onClick={() => setShowReceipt(p)} className="text-brand-700 hover:text-brand-800"><Eye size={16} /></button></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          {filtered.length === 0 && <EmptyState title="No payments found" />}
        </Card>
      </div>

      {/* Payment Entry Modal */}
      <Modal open={showEntry} onClose={closeEntry} title={t('recordPayment')} size="lg">
        {paymentSuccess ? (
          <div className="text-center py-8">
            <div className="w-16 h-16 rounded-full bg-brand-100 flex items-center justify-center mx-auto mb-4">
              <CheckCircle size={32} className="text-brand-600" />
            </div>
            <h3 className="text-lg font-bold text-ink-900 mb-2">Payment Recorded Successfully</h3>
            <p className="text-sm text-ink-500 mb-4">Receipt: REC-2026-001246</p>
            <Button onClick={closeEntry}>{t('close')}</Button>
          </div>
        ) : (
          <div className="space-y-4">
            <Select label={t('subscriber')} value={form.subscriberId} onChange={v => setForm({...form, subscriberId: v})}
              options={[{ value: '', label: 'Select...' }, ...subscribers.map(s => ({ value: s.id, label: `${s.name} (${s.id})` }))]}
              error={errors.subscriberId} required />
            {selectedChit && (
              <div className="bg-ink-50 rounded-lg p-3 text-sm space-y-1">
                <div className="flex justify-between"><span className="text-ink-500">{t('chit')}</span><span className="font-medium text-ink-900">{selectedChit.name}</span></div>
                <div className="flex justify-between"><span className="text-ink-500">{t('monthlyContribution')}</span><span className="font-medium text-ink-900">{formatINR(selectedChit.monthlyContribution)}</span></div>
              </div>
            )}
            <div className="grid grid-cols-2 gap-4">
              <Input label={t('instalmentMonth')} type="number" value={form.instalmentMonth} onChange={v => setForm({...form, instalmentMonth: v})} error={errors.instalmentMonth} required placeholder="6" />
              <Input label={t('paymentDate')} type="date" value={form.paymentDate} onChange={v => setForm({...form, paymentDate: v})} required />
            </div>
            <Input label={t('paymentAmount')} type="number" value={form.paidAmount} onChange={v => setForm({...form, paidAmount: v})} error={errors.paidAmount} required placeholder="50000" />
            {paidAmt > 0 && (
              <div className="bg-brand-50 border border-brand-200 rounded-lg p-3 space-y-1 text-sm">
                <div className="flex justify-between"><span className="text-ink-600">{t('dueAmount')}</span><span className="font-medium tabular-nums">{formatINR(dueAmount)}</span></div>
                <div className="flex justify-between"><span className="text-ink-600">{t('paid')}</span><span className="font-medium tabular-nums">{formatINR(paidAmt)}</span></div>
                <div className="flex justify-between"><span className="text-ink-600">{t('outstandingCol')}</span><span className="font-medium tabular-nums text-red-600">{formatINR(outstanding)}</span></div>
                <div className="flex justify-between border-t border-brand-200 pt-1"><span className="text-ink-700 font-medium">{t('status')}</span><StatusBadge status={payStatus} /></div>
              </div>
            )}
            <Select label={t('paymentMode')} value={form.paymentMode} onChange={v => setForm({...form, paymentMode: v})}
              options={[
                { value: 'cash', label: t('cash') }, { value: 'upi', label: t('upi') },
                { value: 'bank_transfer', label: t('bankTransfer') }, { value: 'cheque', label: t('cheque') },
                { value: 'auto_debit', label: t('autoDebit') }, { value: 'other', label: t('other') },
              ]} />
            <Input label={t('transactionReference')} value={form.transactionRef} onChange={v => setForm({...form, transactionRef: v})} placeholder="UPI-XXXX or CHQ-XXXX" />
            <Input label={t('notes')} value={form.notes} onChange={v => setForm({...form, notes: v})} placeholder="Optional notes" />
            <div className="flex justify-end gap-2"><Button variant="secondary" onClick={closeEntry}>{t('cancel')}</Button><Button onClick={handleSubmit}>{t('confirm')}</Button></div>
          </div>
        )}
      </Modal>

      {/* Receipt Modal */}
      <Modal open={!!showReceipt} onClose={() => setShowReceipt(null)} title={t('viewReceipt')} size="md">
        {showReceipt && (
          <div className="space-y-4">
            <div className="text-center pb-4 border-b border-ink-200">
              <div className="w-12 h-12 rounded-lg bg-brand-700 flex items-center justify-center mx-auto mb-2">
                <span className="text-gold-200 font-bold text-lg font-display">L</span>
              </div>
              <h3 className="font-bold text-ink-900">{t('brandName')}</h3>
              <p className="text-xs text-ink-500">{t('brandSubtitle')}</p>
            </div>
            <div className="space-y-2 text-sm">
              <div className="flex justify-between"><span className="text-ink-500">{t('receiptNo')}</span><span className="font-bold text-ink-900">{showReceipt.receiptNo}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('subscriber')}</span><span className="font-medium text-ink-900">{showReceipt.subscriberName}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('chit')}</span><span className="font-medium text-ink-900">{showReceipt.chitGroupName}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('instalmentMonth')}</span><span className="font-medium text-ink-900">M{showReceipt.instalmentMonth}</span></div>
              <div className="flex justify-between border-t border-ink-200 pt-2"><span className="text-ink-700 font-medium">{t('amount')}</span><span className="text-lg font-bold text-brand-700 tabular-nums">{formatINR(showReceipt.paidAmount)}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('paymentMode')}</span><span className="font-medium text-ink-900 capitalize">{showReceipt.paymentMode.replace('_', ' ')}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('date')}</span><span className="font-medium text-ink-900">{formatDate(showReceipt.paymentDate)}</span></div>
              <div className="flex justify-between"><span className="text-ink-500">{t('outstandingCol')}</span><span className="font-medium text-ink-900">{showReceipt.outstanding > 0 ? formatINR(showReceipt.outstanding) : '₹0'}</span></div>
            </div>
            <div className="flex gap-2 no-print">
              <Button variant="secondary" className="flex-1" onClick={() => window.print()}><Printer size={16} /> {t('print')}</Button>
              <Button variant="secondary" className="flex-1"><Download size={16} /> {t('download')}</Button>
              <Button variant="secondary" className="flex-1"><Share2 size={16} /> {t('share')}</Button>
            </div>
          </div>
        )}
      </Modal>
    </div>
  );
}

import type { UserRole } from '@/types';
import type { TranslationKey } from '@/i18n/translations';
import {
  LayoutDashboard, Users, Users2, Gavel, HandCoins, Wallet, Coins, Trophy,
  AlertCircle, BookOpen, FileBarChart, Building2, ShieldCheck, FileText,
  Bell, ScrollText, Settings, Calculator,
} from 'lucide-react';

export interface NavItem {
  id: string;
  labelKey: TranslationKey;
  icon: typeof LayoutDashboard;
  roles: UserRole[];
}

export const navItems: NavItem[] = [
  { id: 'dashboard', labelKey: 'dashboard', icon: LayoutDashboard, roles: ['super_admin', 'branch_manager', 'accountant', 'collection_staff', 'auction_staff'] },
  { id: 'chitGroups', labelKey: 'chitGroups', icon: Users, roles: ['super_admin', 'branch_manager', 'accountant', 'collection_staff', 'auction_staff'] },
  { id: 'subscribers', labelKey: 'subscribers', icon: Users2, roles: ['super_admin', 'branch_manager', 'accountant', 'collection_staff', 'auction_staff'] },
  { id: 'auctions', labelKey: 'auctions', icon: Gavel, roles: ['super_admin', 'branch_manager', 'auction_staff'] },
  { id: 'collections', labelKey: 'collections', icon: HandCoins, roles: ['super_admin', 'branch_manager', 'collection_staff'] },
  { id: 'payments', labelKey: 'payments', icon: Wallet, roles: ['super_admin', 'branch_manager', 'accountant', 'collection_staff'] },
  { id: 'dividends', labelKey: 'dividends', icon: Coins, roles: ['super_admin', 'branch_manager', 'accountant'] },
  { id: 'prizePayments', labelKey: 'prizePayments', icon: Trophy, roles: ['super_admin', 'branch_manager'] },
  { id: 'outstanding', labelKey: 'outstanding', icon: AlertCircle, roles: ['super_admin', 'branch_manager', 'collection_staff', 'accountant'] },
  { id: 'ledger', labelKey: 'ledger', icon: BookOpen, roles: ['super_admin', 'branch_manager', 'accountant'] },
  { id: 'reconciliation', labelKey: 'reconciliation', icon: ScrollText, roles: ['super_admin', 'accountant'] },
  { id: 'reports', labelKey: 'reports', icon: FileBarChart, roles: ['super_admin', 'branch_manager', 'accountant'] },
  { id: 'calculator', labelKey: 'chitCalculator', icon: Calculator, roles: ['super_admin', 'branch_manager', 'accountant', 'collection_staff', 'auction_staff'] },
  { id: 'branches', labelKey: 'branches', icon: Building2, roles: ['super_admin'] },
  { id: 'staff', labelKey: 'staffRoles', icon: ShieldCheck, roles: ['super_admin', 'branch_manager'] },
  { id: 'documents', labelKey: 'documents', icon: FileText, roles: ['super_admin', 'branch_manager', 'accountant'] },
  { id: 'notifications', labelKey: 'notifications', icon: Bell, roles: ['super_admin', 'branch_manager', 'accountant', 'collection_staff', 'auction_staff'] },
  { id: 'auditTrail', labelKey: 'auditTrail', icon: ScrollText, roles: ['super_admin', 'branch_manager'] },
  { id: 'settings', labelKey: 'settings', icon: Settings, roles: ['super_admin'] },
];

export function getNavItemsForRole(role: UserRole): NavItem[] {
  return navItems.filter(item => item.roles.includes(role));
}

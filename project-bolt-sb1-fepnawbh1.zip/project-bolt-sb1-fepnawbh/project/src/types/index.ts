export type UserRole = 'super_admin' | 'branch_manager' | 'accountant' | 'collection_staff' | 'auction_staff' | 'customer';

export type ChitStatus = 'upcoming' | 'active' | 'completed' | 'suspended' | 'closed';
export type SubscriberStatus = 'active' | 'non_prized' | 'prized' | 'partial' | 'overdue' | 'defaulted' | 'transferred' | 'closed';
export type AuctionStatus = 'scheduled' | 'open' | 'completed' | 'pending_approval' | 'cancelled';
export type PaymentStatus = 'paid' | 'partial' | 'pending' | 'overdue' | 'failed';
export type PaymentMode = 'cash' | 'upi' | 'bank_transfer' | 'cheque' | 'auto_debit' | 'other';
export type KycStatus = 'pending' | 'verified' | 'rejected' | 'expired';
export type DocumentStatus = 'pending' | 'verified' | 'rejected' | 'expired';
export type ApprovalStatus = 'draft' | 'submitted' | 'under_review' | 'approved' | 'rejected' | 'completed';
export type DividendDistributionRule = 'equal' | 'agreement_defined' | 'other';
export type AuctionMethod = 'open_auction' | 'sealed_bid';
export type TransactionType = 'subscription' | 'dividend' | 'prize_payment' | 'commission' | 'penalty' | 'adjustment' | 'reversal' | 'refund';

export interface Branch {
  id: string;
  name: string;
  manager: string;
  address: string;
  phone: string;
  activeChits: number;
  subscribers: number;
  monthlyCollection: number;
  outstanding: number;
  status: 'active' | 'inactive';
}

export interface StaffUser {
  id: string;
  name: string;
  role: UserRole;
  branch: string;
  email: string;
  phone: string;
  status: 'active' | 'inactive';
  lastLogin: string;
  permissions: {
    view: boolean;
    create: boolean;
    edit: boolean;
    approve: boolean;
    export: boolean;
  };
}

export interface ChitGroup {
  id: string;
  name: string;
  chitValue: number;
  members: number;
  duration: number;
  monthlyContribution: number;
  currentMonth: number;
  commissionPercent: number;
  status: ChitStatus;
  branch: string;
  startDate: string;
  nextAuctionDate: string;
  auctionMethod: AuctionMethod;
  maxDiscountPercent: number;
  dividendRule: DividendDistributionRule;
  gracePeriodDays: number;
  penaltyRate: number;
}

export interface Subscriber {
  id: string;
  name: string;
  phone: string;
  email: string;
  dateOfBirth: string;
  address: string;
  nominee: string;
  pan: string;
  aadhaar: string;
  addressProof: string;
  kycStatus: KycStatus;
  chitGroupId: string;
  ticketNo: number;
  joiningDate: string;
  status: SubscriberStatus;
  totalPaid: number;
  outstanding: number;
  prizeStatus: 'prized' | 'non_prized';
  prizeMonth?: number;
  prizeAmount?: number;
  lastPaymentDate: string;
  branch: string;
  dividendReceived: number;
  futureLiability: number;
}

export interface AuctionBid {
  subscriberId: string;
  subscriberName: string;
  ticketNo: number;
  bidDiscount: number;
  submittedAt: string;
  status: 'pending' | 'winner' | 'rejected';
}

export interface Auction {
  id: string;
  chitGroupId: string;
  chitGroupName: string;
  month: number;
  date: string;
  chitAmount: number;
  eligibleSubscribers: number;
  bids: AuctionBid[];
  highestDiscount: number;
  winnerId?: string;
  winnerName?: string;
  prizeAmount?: number;
  commission?: number;
  dividendPool?: number;
  status: AuctionStatus;
  approvedBy?: string;
  approvedAt?: string;
}

export interface Payment {
  id: string;
  receiptNo: string;
  subscriberId: string;
  subscriberName: string;
  chitGroupId: string;
  chitGroupName: string;
  instalmentMonth: number;
  dueAmount: number;
  paidAmount: number;
  outstanding: number;
  paymentMode: PaymentMode;
  paymentDate: string;
  transactionRef: string;
  status: PaymentStatus;
  notes: string;
  branch: string;
}

export interface LedgerEntry {
  id: string;
  transactionId: string;
  date: string;
  account: string;
  description: string;
  debit: number;
  credit: number;
  balance: number;
  reference: string;
  createdBy: string;
  type: TransactionType;
  chitGroup: string;
  branch: string;
}

export interface AuditEntry {
  id: string;
  user: string;
  role: string;
  action: string;
  record: string;
  oldValue: string;
  newValue: string;
  timestamp: string;
  reason: string;
  ipAddress: string;
  approvalStatus: ApprovalStatus;
  approvedBy?: string;
}

export interface DividendRecord {
  id: string;
  chitGroupId: string;
  chitGroupName: string;
  auctionId: string;
  month: number;
  dividendPool: number;
  subscribers: number;
  dividendPerMember: number;
  totalDistributed: number;
  unallocatedBalance: number;
  status: 'pending' | 'distributed' | 'approved';
  date: string;
}

export interface PrizeRecord {
  id: string;
  subscriberId: string;
  subscriberName: string;
  chitGroupId: string;
  chitGroupName: string;
  chitValue: number;
  auctionMonth: number;
  discount: number;
  prizeAmount: number;
  commission: number;
  dividendPool: number;
  remainingMonths: number;
  futureLiability: number;
  status: ApprovalStatus;
  approvedBy?: string;
  approvedAt?: string;
}

export interface Notification {
  id: string;
  type: 'payment_due' | 'payment_received' | 'auction_scheduled' | 'dividend_credited' | 'overdue' | 'prize_approved' | 'general';
  title: string;
  titleTa: string;
  message: string;
  messageTa: string;
  date: string;
  read: boolean;
  forRole: UserRole | 'all';
}

export interface DocumentRecord {
  id: string;
  subscriberId: string;
  subscriberName: string;
  type: 'aadhaar' | 'pan' | 'address_proof' | 'photograph' | 'nominee' | 'chit_agreement' | 'prize_docs';
  name: string;
  status: DocumentStatus;
  uploadedDate: string;
  verifiedBy?: string;
}

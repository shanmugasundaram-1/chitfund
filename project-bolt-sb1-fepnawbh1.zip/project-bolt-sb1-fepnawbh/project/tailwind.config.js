/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      fontFamily: {
        sans: ['Inter', 'Noto Sans Tamil', 'system-ui', 'sans-serif'],
        display: ['Plus Jakarta Sans', 'Noto Sans Tamil', 'system-ui', 'sans-serif'],
        tamil: ['Noto Sans Tamil', 'Inter', 'sans-serif'],
      },
      colors: {
        brand: {
          50: '#f0f9f4',
          100: '#dcf0e3',
          200: '#bbe1c9',
          300: '#8bcba6',
          400: '#54ad80',
          500: '#2f8d62',
          600: '#1f704d',
          700: '#1a5a40',
          800: '#174834',
          900: '#143b2c',
          950: '#0a2118',
        },
        gold: {
          50: '#fbf8ef',
          100: '#f5edd5',
          200: '#ecd9a8',
          300: '#e0bf73',
          400: '#d6a94b',
          500: '#c9942f',
          600: '#ab7426',
          700: '#885622',
          800: '#714621',
          900: '#603b20',
        },
        ink: {
          50: '#f7f7f6',
          100: '#eeeee9',
          200: '#dadbd3',
          300: '#bbbdb0',
          400: '#96988a',
          500: '#7a7c6f',
          600: '#5f6157',
          700: '#4a4c45',
          800: '#3a3c37',
          900: '#252622',
          950: '#151613',
        },
      },
      boxShadow: {
        card: '0 1px 2px 0 rgba(20, 22, 19, 0.04), 0 1px 3px 0 rgba(20, 22, 19, 0.06)',
        'card-hover': '0 4px 12px -2px rgba(20, 22, 19, 0.08), 0 2px 6px -2px rgba(20, 22, 19, 0.06)',
        'elevated': '0 10px 30px -10px rgba(20, 22, 19, 0.15), 0 4px 12px -4px rgba(20, 22, 19, 0.08)',
      },
      borderRadius: {
        'xl2': '1rem',
      },
    },
  },
  plugins: [],
};
